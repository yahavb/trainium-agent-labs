# Heat-Rod Agent: One-Page Project Report
Seat 203 | October 10, 2026 | Status: selective Level1.2 passed; latest full-suite validation pending

## Objective and setup
Build a faster model-driven heat-equation solver with reliable feedback, without changing model weights. We used Qwen/Qwen3-8B through vLLM on an AWS Trainium2 trn2.48xlarge, in seat-203. Level 0 covers zero-temperature ends and sine-wave initial shapes; Level 1 adds an insulated end and a parabola requiring a truncated Fourier expansion. Live comparison runs used 4 samples, up to 4 rounds, 1 tool exchange and seed 0; later controlled commands also fixed a 16-candidate budget and 1,200 output tokens.

## What we changed
We first ran the original code and checker selftests: Level 0 solved 3/3 and Level 1 solved 2/3; Level1.3 stalled on decay rates and coefficients. We then tested a friend-provided revision with explicit basis/projection/rate instructions, structured feedback and historical-best repair. Next, we instrumented latency, removed split timers, and implemented parallel sample collection with immediate full-answer grading and early stopping at the first reward 1.0. Cancelled samples keep null scores.

## Shared calculations and repairs
A parent-owned calculator broker reuses completed and in-flight requests across samples, scoped to the current problem. Optional MODE requests check the basis, coefficient and rate. Live logs exposed false rejections: numeric coefficients and orthogonality-reduced projections were initially disallowed. We fixed this by verifying against the actual normalized projection in a tool worker and separating coefficient validation from rate feedback. We added request/response traces and a strict parser whitelist for text-wrapped exp, sin and cos. The latest agent prompt reuses coefficients already present in allowed waves and requests projections only when expansion is needed; the selective version has now solved Level1.2 in one round at 148.0 s.

## Checker acceptance and validation
The final checker retains weights of 0.4 for the PDE and 0.2 each for the two boundaries and initial shape. Full credit requires all four conditions, including the 0.5% initial-shape tolerance for the parabola. Safe finite-expression parsing rejects unknown symbols, unresolved sums/integrals and unsupported commands. Format normalization does not excuse incorrect physics: the observed wrapped wrong decay rate still scores 0.6. Local tests passed both level selftests, all four boundary pairs, intermediate validation, single-flight/cache reuse, cancellation cleanup and null-score logging.

## Results and limits
The friend revision solved Level1.3 seed 0 in two separate first-round runs: 234.3 and 216.8 s (median 225.6 s); seed 1 solved in 193.2 s. The uploaded archive contains three complete earlier shared-version sweeps, each solving 6/6 (18/18 final problem outcomes). Their round-time sums were 368.9, 789.8 and 352.7 s: median 368.9 s, range 352.7-789.8 s. The interrupted duplicate batch is retained and excluded from these totals. Level1.2 varied substantially, as shown below. Earlier timing attributed most latency to model requests/queueing (about 401 s for one sample), versus 0.165 s for total final grading in that round. Local worker cancellation is verified; server-side abort and total token cost remain unconfirmed. The selective result is one single-problem run, not a repeated full-suite benchmark. Batch overlap and sampling variation limit comparisons. Baseline/friend results come from terminal transcripts; their original attempt files are absent from the uploaded archive.

| Level1.2 observation | Rounds to solve | Round-time sum |
|---|---:|---:|
| Original baseline | 2 | 429.7 s |
| Initial shared run | 1 | 59.2 s |
| Shared batch run with rejections | 4 | 517.5 s |
| Intermediate-validation repair | 2 | 344.0 s |
| Format repair | 1 | 210.5 s |
| Selective tool guidance (latest) | 1 | 148.0 s |

Times above are logged round durations, not full process runtimes. Versions and sample paths differ; do not infer a statistical speedup from this table.

Reproduction: run agent_shared.py --level 0/1 --all --samples 4 --rounds 4 --attempt-budget 16 --max-tokens 1200 --tool-steps 1 --seed 0, with unique JSONL and console logs. Evidence: uploaded run logs, terminal transcripts and local regression tests.
