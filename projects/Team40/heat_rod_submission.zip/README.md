# Heat-Rod Agent - Seat 203 submission

## Contents and provenance

The final agent_shared.py and pdecheck.py are byte-identical to the participant's latest uploaded files (agent_shared(1).py and pdecheck(4).py). They include selective tool guidance, shared calculator reuse, immediate full-answer grading, and the C11/C12 checker repairs. The unchanged level files and tool_calc.py come from the workshop files supplied in this session and pass local validation with the final code. CHANGE_GUIDE.md explains the modifications. REPORT.md and the one-page PDF describe the complete development and current evidence.

Logs are copied byte-for-byte from heat_shared_logs.tar.gz, preserving failures and cancelled attempts. The archive includes older versions; do not attribute every log to the final source files.

## Log/version map

| Folder under logs/ | Version / status |
|---|---|
| batch_20261010_210439_kxgfFe | Earlier shared version; 3 complete Level0+Level1 sweeps, each ultimately 6/6. Round sums: 368.9, 789.8, 352.7 s; median 368.9 s. |
| batch_20261010_210518_uFe51X | Interrupted duplicate batch; retained, excluded from completed-sweep statistics. |
| fixed_level1_2_yjvcJR | Intermediate-validation repair; Level1.2 solved after 2 rounds, 344.0 s. |
| formatfix_level1_2_Tkczmn | Format repair; Level1.2 solved after 1 round, 210.5 s. |
| selective_level1_2_fQNxXs | Latest selective agent; Level1.2 solved after 1 round, 148.0 s. |

The original baseline and friend-version results in the report are supported by terminal transcripts; their original JSONL/log files were not included in the uploaded archive. The initial shared 59.2 s observation is also from the terminal transcript. The latest selective code has only one live Level1.2 run here, not a repeated complete-suite evaluation. Runs may be affected by model sampling, endpoint queueing and initial batch overlap. Round durations are not complete process runtimes.

## Run in the Linux seat pod

The model server must already be serving Qwen/Qwen3-8B at the endpoint. The agent uses Linux fork. Install requirements only if the pod does not already have them.

```bash
cd /path/to/extracted/submission
python -m pip install -r requirements.txt
export HEATROD_BASE_URL=http://localhost:8000/v1
python -m py_compile agent_shared.py pdecheck.py
python validate_selective.py
```

Run both levels with the recorded budgets and unique output directories:

```bash
mkdir -p logs
run_dir=$(mktemp -d "$PWD/logs/reproduction_XXXXXX")
for level in 0 1; do
  python -u agent_shared.py \
    --level "$level" --all --seed 0 \
    --samples 4 --rounds 4 --attempt-budget 16 \
    --max-tokens 1200 --tool-steps 1 \
    --log "$run_dir/level${level}.jsonl" \
    > "$run_dir/level${level}.log" 2>&1 || exit $?
done
```

For the latest single-problem comparison, replace --level "$level" --all with --level 1 --sub 2. Do not use --offline for performance claims: offline results use a simulated generator.

## Interpretation

Reward 1.0 means a complete answer passed the PDE, both boundaries and initial shape. Verified intermediate modes cannot trigger success by themselves. Cancelled/error samples keep null scores; a first success among four candidates is not pass@1. Local process stopping does not establish server-side request abortion or measured total token cost.

No credentials are needed in this submission package. Endpoint configuration is supplied at runtime.
