import sys, json
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent))
import pdecheck as c, level1_heatrod as l
import level0_heatrod
assert level0_heatrod.selftest() == 0
assert l.selftest() == 0
p=l.make(2)
valid=[('sin(pi*x/6)','1','pi**2/24'),('sin(5*pi*x/6)','2','25*pi**2/24'),('sin(pi*x/6)','(2/3)*Integral(sin(pi*x/6)**2,(x,0,3))','pi**2/24')]
for wave,expression,rate in valid:
 r=c.check_intermediate(p,dict(kind='mode',wave=wave,expression=expression,rate=rate))
 assert r['verified'] and r['shareable'], r
for rate in ['3*pi**2/8','k*omega**2','']:
 r=c.check_intermediate(p,dict(kind='mode',wave='sin(5*pi*x/6)',expression='2',rate=rate))
 assert r['verified'] and r['mode']['coefficient']=='2' and r['mode']['rate']=='25*pi**2/24',r
 assert 'Supplied decay rate failed' in r['text']
for expression in ['1','2.01','2.00001','Integral(sin(pi*x/6)**2,(x,0,3))']:
 r=c.check_intermediate(p,dict(kind='mode',wave='sin(5*pi*x/6)',expression=expression,rate='25*pi**2/24'))
 assert not r['verified'] and not r['shareable'] and r['mode'] is None,r
print(json.dumps({'status':'passed','numeric_and_reduced_projection_cases':3,'partial_rate_repairs':3,'wrong_coefficients_rejected':4,'live_model_runs':0}))

# CHANGE FORMAT C12 regression: harmless wrappers do not bypass mathematical checks.
correct = r"u(x,t) = \text{exp}(-\pi**2*t/24)*\text{sin}(\pi*x/6) + 2*\text{exp}(-25*pi**2*t/24)*\text{sin}(5*pi*x/6) $$"
wrong = correct.replace("25*pi**2*t/24", "3*pi**2*t/8")
assert c.check(p, correct)["reward"] == 1.0
assert c.check(p, wrong)["reward"] == 0.6
assert c.parse(r"\text{cos}(pi*x)") == c.parse("cos(pi*x)")
for bad in (r"\text{foo}(x)", r"\text{x}", r"\text{exp(x)}", r"\text{\sin}(x)", r"\text{exp", r"\text{sin + cos}(x)"):
    try:
        c.parse(bad)
    except (ValueError, SyntaxError):
        pass
    else:
        raise AssertionError("Unsupported wrapper accepted: " + bad)
print(json.dumps({"format_regression": "passed", "wrong_decay_reward": 0.6}))
