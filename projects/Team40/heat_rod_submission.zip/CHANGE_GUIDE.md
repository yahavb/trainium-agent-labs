# Selective calculator use (CHANGE SPEED A19)

The agent now tells the model to reuse coefficients already present in a finite sum of allowed boundary-compatible waves. It asks for projections only when the initial shape needs expansion. PDE-only repairs preserve accepted waves and coefficients and focus on beta=k*omega**2. The model can answer directly, without a tool exchange. Sample plans no longer uniformly request new projections.

This is generic model guidance, not a controller-generated PDE answer or a hard-coded level/subproblem shortcut. Tools remain available on every problem when the model needs them. No reference answers, coefficients or frequencies are calculated by the controller for this new prompt. Calculator concurrency, sharing, final grading, sampling/token/round budgets and early stop are unchanged. No new timing instrumentation was added.

Local validation passed with mocked model calls, including direct answers with zero tool calls, retained calculator exchanges, shared-cache integration tests and original selftests. No live-model latency or accuracy improvement is claimed. Benchmark against the prior version under the same budgets; repeat each test and preserve failures.

The package contains the updated agent, the latest checker (including C11 and C12 repairs), the existing math/format validation script and a selective-use validation script. Existing level0_heatrod.py, level1_heatrod.py and tool_calc.py are required in the project directory.

```bash
python -m py_compile agent_shared.py pdecheck.py
python validate_selective.py
```

# Shared calculator repair

## Format repair (CHANGE FORMAT C12)

The final-expression normalizer now rewrites only `\\text{exp}`, `\\text{sin}` and `\\text{cos}` into their existing allowed function names. Whitespace inside the braces is allowed. Unknown names, arbitrary text and nested commands remain rejected. The same AST whitelist and full mathematical checks run afterward. A wrapped correct Level1.2 answer receives 1.0; the observed wrapped wrong decay rate receives 0.6 rather than a format zero. The repair does not make an incorrect decay rate pass. No agent change was needed for this format repair.

## What changed

- **pdecheck.py, CHANGE SHARED C11:** MODE coefficients may be numeric, full projections, or mathematically equivalent reduced projections. Nonstandard setups are checked in a calculator worker against the actual normalized projection of the current initial shape. A wrong coefficient is rejected and never cached or broadcast.
- Coefficient equality is exact where possible. Rounded values allow only 1e-10 relative to max(1, abs(projection)); this does not change the full-answer initial-shape tolerance.
- Rates are checked independently. When a coefficient passes but a rate fails (including invalid rate syntax), return the verified coefficient and the rate calculated from k*omega**2, clearly identifying the failed supplied rate. This is mathematical tool feedback, not final-answer acceptance.
- Unchecked numeric/simplified coefficient requests have distinct cache keys. They cannot reuse a certified projection entry before verification. Rate-specific feedback cannot leak between different supplied rates.
- **agent_shared.py, CHANGE SHARED A17:** usual COMPUTE requests are the primary protocol again. MODE is optional, reducing protocol burden.
- **agent_shared.py, CHANGE SHARED A18:** JSONL records include intermediate_trace with actual requests and returned validation messages, including rejection reasons. Cancellation may leave unfinished requests without a returned result.

## What remains

Only the three listed final-expression wrappers are newly normalized. PDE/boundary/initial-shape checks, rewards and tolerances are unchanged. Individual verified modes do not constitute a complete solution. Four samples still run in parallel and stop at the first complete checker pass. Cancelled candidates retain null scores. No split timing was added. Server-side request cancellation remains unconfirmed.

## Validation

Local tests passed: both original level selftests; DD/DN/ND/NN including constant normalization; numeric and orthogonality-reduced coefficients; independent rate feedback; incorrect coefficients rejected; single-flight sharing; cross-round cache; early stopping and calculator cancellation; null cancelled scores; baseline prompt parity; no orphan workers. Complete-answer check implementation entry points are byte-for-byte unchanged. These are local tests with mocked generation, not live model benchmarks.

Run in the seat pod after copying these files next to existing level0_heatrod.py, level1_heatrod.py and tool_calc.py:

```bash
python -m py_compile agent_shared.py pdecheck.py
python validate_shared_fix.py
```

## Benchmark first

Wait for the current batch to finish before replacing code or starting another batch. Preserve its logs. First repeat level 1 subproblem 2 under the same samples, token, round and tool budgets. Use a new unique log directory for every test. Compare solve rate and median end-to-end time across repeats; a first-round solve or speed improvement is not guaranteed. Then rerun both full levels. Existing logs remain evidence of the earlier version.

The archive contains replacement agent_shared.py and pdecheck.py, this guide and validate_shared_fix.py. It relies on the existing level files and tool_calc.py in your remote project directory.
