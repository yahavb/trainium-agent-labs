#!/usr/bin/env python3
"""Local regression tests; mocked generation is not a model benchmark."""
from types import SimpleNamespace
import json
import sympy as sp
import validate_shared_fix  # Original selftests plus intermediate and format regressions.
import agent_shared as agent
import pdecheck

p = agent.level1_heatrod.make(2)
a = SimpleNamespace(offline=False, no_tools=False, tool_steps=1, no_shared_calculations=False)
plan = agent.calculator_plan(p, True)
assert 'Do not re-integrate' in plan
assert 'Otherwise project f' in plan
assert 'no projection is needed' in plan
assert 'Tools are disabled' in agent.calculator_plan(p, False)
# Instruction generation must not inspect any stored reference solution or coefficient.
class NoReference(dict):
    def __getitem__(self, key):
        assert key in ('left', 'right'), key
        return super().__getitem__(key)
assert agent.calculator_plan(NoReference(left='dirichlet', right='neumann'), True) == plan
answer = 'u(x,t) = ' + sp.sstr(p['exact'])
original = agent.ask_once
try:
    calls = []
    def direct(args, prompt):
        calls.append(prompt)
        return answer
    agent.ask_once = direct
    result, used = agent.one_attempt(a, p, plan, 0)
    assert used == 0 and len(calls) == 1
    assert pdecheck.check(p, result)['reward'] == 1.0

    calls.clear()
    def needs_tool(args, prompt):
        calls.append(prompt)
        return answer if 'give the final answer now' in prompt else 'COMPUTE: (3/2)*(5*pi/6)**2'
    agent.ask_once = needs_tool
    result, used = agent.one_attempt(a, p, plan, 0)
    assert used == 1 and len(calls) == 2
    assert '25*pi**2/24' in calls[-1]
    assert pdecheck.check(p, result)['reward'] == 1.0
finally:
    agent.ask_once = original
print(json.dumps({'selective_use': 'passed', 'direct_model_requests': 1, 'optional_tool_model_requests': 2, 'live_model_runs': 0}))
