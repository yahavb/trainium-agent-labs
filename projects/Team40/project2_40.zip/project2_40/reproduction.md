# Reproduction note

Two runs. Both are Qwen3-8B, thinking off, five repeats of levels 1–4, and both solve every level 5/5. Report the rate for the run you are citing. Do not mix their sample counts or their token estimates.

## Optimized run (seat-201)

This is `agent_optimized.py`. Each level has its own API card on round 0, and the grader names the failing line. Levels 2–4 also print simulator DMA bytes.

```bash
cd /workspace/projects/02-kernel-agent
python agent_optimized.py --all --rounds 8 --samples 4 --context 8192 --repeat 5
```

Seat pod `seat-201`, container `app`. The model server is `./serve.sh` from `/workspace` (`MAX_MODEL_LEN=8192`). The endpoint in the log is `http://localhost:8000/v1`, model `Qwen/Qwen3-8B`. Attempts go to `attempts_four_backups.jsonl` unless `--log` is set. The text log copied here is `run_optimized.log`.

| Level | Solved | Rounds until solved |
|---|---|---|
| 1 average pooling 2D | 5/5 | 2 (solved on round 1) |
| 2 2D transpose | 5/5 | 1 (solved on round 0) |
| 3 matmul, single tile | 5/5 | 1 (solved on round 0) |
| 4 matmul, tiled | 5/5 | 1 (solved on round 0) |

100 candidates, 71 passed, 29 failed. The 29 are classified in `error_classification_optimized.md`: 20 level-1 `NameError` on the unbound window `p`, and 9 level-3 `dma_copy` mismatches (src=8192, dst=16384). Character counts and both token estimates (`ceil(chars/4)` and `ceil(chars/3)`) are in `token_usage_optimized.md`. Input characters total 202,820.

The printed round seconds include the model call and the checker, because both sit inside one timer. They are not device kernel latency.

## First run (seat-204)

This is `agent.py`. Round 0 uses one shared API card. The level-specific steps arrive in the repair prompt.

```bash
python agent.py --all --rounds 8 --samples 4 --context 8192 --repeat 5
```

The log is `run.log`. Level 1 solved on round 2, level 2 on round 1, level 3 on round 1, level 4 on round 2, each at 5/5. 200 candidates, 80 passed. Failures are in `failure-taxonomy.md`. The token note for this run only is `token-usage.md` (characters / 4, split into docs, checker text, and previous code).

Flags shared by both commands: `--all` is levels 1–4, `--rounds 8` is the cap, `--samples 4` keeps the best of four, `--context 8192` is the server input limit, `--repeat 5` is the rate to report. `--terse` stayed at 0. Temperature 0.6, top_p 0.95. `enable_thinking` is false unless `--think` is passed.

## What the score is

`nkibench.py` grades in three steps: static rules, then `nki.simulate` on CPU, then HBM bytes versus the byte floor. Numerical tolerance is `tol=2e-2` in `verify()`: the worst absolute error divided by the reference RMS must be at most 0.02. The tolerance is relative because matmul outputs on these shapes have RMS around 10.

`nki.simulate` is a functional simulator. Arithmetic intensity in `speed-report.txt` is flops divided by simulated HBM bytes. The published ridge, 222 Flops/Byte, is the bfloat16 figure; these checks ran in float32, so the bound is indicative. Ceilings if every input is read once and the output is written once: level 3 is 19.7; level 4 is 28.4, 56.9, 42.7, 73.1.

The optimized level-4 SOLVED lines print 589,824 / 3,670,016 / 1,572,864 / 7,340,032 DMA bytes. That matches `reference_level4.py`: tiles are re-read inside the K loop, and the two large shapes are 1.6× and 2.0× the byte floor. `level4_fast.py`, checked with `python nkibench.py --level 4 --check level4_fast.py`, is numerically 4/4 and at 1.00× the floor (intensities 28.4, 56.9, 42.7, 73.1). Those numbers are in `speed-report.txt`. They are a separate kernel, not the agent’s solve rate.

The optimized level-2 grader also requires exact values and the same dtype, on top of the harness tolerance.

## Eval set

Shapes are `nkibench.LEVELS`, seed 0. The awkward ones are here on purpose: pool 3 on a side of 24, a transpose whose free dimension is 35 = 5×7, and matmul shapes whose K is 256 or 512 so a single tile is illegal past the partition limit of 128.

| Level | Cases |
|---|---|
| 1 | C,H,W = (32,32,32) pool 2; (128,16,16) pool 4; (8,24,24) pool 3; (64,8,8) pool 2 |
| 2 | (32,12) as 3×4; (128,64) as 8×8; (64,128) as 4×32; (8,35) as 5×7 |
| 3 | K=128, M=64, N=512 |
| 4 | K,M,N = (128,128,512), (256,256,1024), (512,128,512), (256,512,1024) |

Levels 5–7 reuse the level-4 shapes and add HBM traffic bars (1.6×, 1.25×, 1.05×). Level 8 is single-head attention at (seq, dim) = (128, 64), (64, 128), (96, 32). Neither run entered levels 5–8.

## Files

| File | Run | Role |
|---|---|---|
| `agent.py` | first | Agent, shared API card, repair-time steps |
| `run.log` | first | Five-run record, seat-204 |
| `failure-taxonomy.md` | first | 120 failed samples |
| `token-usage.md` | first | chars/4, docs vs checker vs code |
| `agent_optimized.py` | optimized | Per-level cards and graders |
| `run_optimized.log` | optimized | Five-run record, seat-201 |
| `error_classification_optimized.md` | optimized | 29 failed samples, two categories |
| `token_usage_optimized.md` | optimized | chars/4 and chars/3 |
| `nkibench.py` | both | Harness: rules, tolerance, shapes, traffic |
| `reference_level1.py` … `reference_level4.py` | both | Reference kernels |
| `speed-report.txt` | traffic | Simulator bytes for the references and for `level4_fast.py` |
| `level4_fast.py` | traffic | Hand-written level-4 kernel at the byte floor |
| `README-41project2.md` | both | What the two runs did |
