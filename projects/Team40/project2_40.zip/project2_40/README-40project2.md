# What this project did

Project 2. Qwen3-8B writes NKI kernels inside an 8192-token input budget, and the checker scores them. The score comes from `nki.simulate`, a functional simulator on the CPU. It checks results and HBM traffic. It is not a Trainium timing run.

There are two measured five-run records. Both solve levels 1–4 at 5/5. They use different agents, different seats, and different logs. The numbers below stay with the file they came from.

| | First run | Optimized run |
|---|---|---|
| Agent | `agent.py` | `agent_optimized.py` |
| Seat | seat-204 | seat-201 |
| Log | `run.log` | `run_optimized.log` |
| Failures | `failure-taxonomy.md` | `error_classification_optimized.md` |
| Tokens | `token-usage.md` | `token_usage_optimized.md` |
| Samples | 200 | 100 |
| Passed samples | 80 | 71 |
| Level 1 solved | round 2 | round 1 |
| Levels 2, 3, 4 solved | rounds 1, 1, and 2 | round 0 on every run |

`speed-report.txt` and `level4_fast.py` are a separate simulator measurement of HBM traffic. They are not either agent’s solve rate. `reproduction.md` has the commands, the tolerance, and the eval shapes.

## First run

`agent.py` sends the task, the NumPy reference, and one shared API card on round 0. From round 1 it sends the previous kernel, the checker text, and the concrete next edit for that level. Each round draws 4 samples and repairs the latest attempt. The same failure string stops a level after 4 repeats. Thinking is off.

Command:

```bash
python agent.py --all --rounds 8 --samples 4 --context 8192 --repeat 5
```

Result in `run.log`: every level solved 5/5. Level 1 took 3 rounds, level 2 took 2, level 3 took 2, level 4 took 3. Of 200 samples, 120 failed before the solving round. The repeated path is in `failure-taxonomy.md`: level 1 copied the 2×2 window (`src=4`, `dst=16384`) and then called `nisa.multiply`; level 4 often allocated a partition of 256 (score 0.62) and then dropped the entry name `nki_matmul_tiled_` (score 0.10).

`token-usage.md` estimates tokens as characters / 4, because `attempts.jsonl` stores character counts and the endpoint did not return a usage object. Mean input is about 670 tokens per call. The largest prompt is about 1,078 tokens. Round 0 is the task and the API card. On repair rounds the checker text is about half of the prompt and the previous kernel is about 40%.

## Optimized run

`agent_optimized.py` keeps the same loop, the same weights (parses 0.1, rules 0.2, runs 0.2, correct 0.5), 4 samples, and thinking off. The change is that each level has its own prompt, its own API card, and its own grader, and that card is sent on round 0.

- Level 1’s card is the whole-tensor pool: `tile.ap`, `nl.sum(view, axis=[3, 4])`, then `nisa.tensor_scalar` with `op0=nl.multiply`. The window is named `p`.
- Level 2’s card keeps the output at `x.shape` and copies columns with `nisa.tensor_copy` and `nl.ds`. The grader also requires an exact value and dtype match, because a transpose only moves values.
- Level 3’s card is one tile, K=128, M=64, N=512, with SBUF, PSUM, and the HBM output each given their own shape.
- Level 4’s card tiles at 128, 128, and 512, allocates one PSUM outside the K loop, and reloads tiles inside that loop. The card says this version is for correctness on the supplied tests.

A failing sample’s feedback now includes the candidate line that raised, plus a short fix for that error. A solved level 2–4 line also prints simulator DMA bytes and DMA call counts for every shape.

Command, on seat-201:

```bash
python agent_optimized.py --all --rounds 8 --samples 4 --context 8192 --repeat 5
```

The log default for attempts is `attempts_four_backups.jsonl`. The text record in this folder is `run_optimized.log`.

Result: levels 1–4 solved 5/5. Level 1 passes on round 1. Levels 2, 3, and 4 pass on round 0, so those three levels never enter a repair prompt. Across 100 candidates, 71 pass and 29 fail. `error_classification_optimized.md` has only two recorded failure kinds:

| Failure | Where | Candidates |
|---|---|---:|
| `NameError: name 'p' is not defined` | Level 1, round 0, all 4 samples, all 5 runs | 20 |
| `dma_copy` src=8192, dst=16384 | Level 3, some samples on round 0 | 9 |

Level 3 still solves on round 0 because the best of the four samples is correct. Level 2 and level 4 have no failed candidates in this record. The JSONL has no run or sample id; those columns were inferred by lining the text log up with batches of four. The grader reports the first failing case only.

`token_usage_optimized.md` uses the same character records and states that the API token counts were not stored. It reports both `ceil(characters/4)` and `ceil(characters/3)`. Input characters total 202,820, about 50,760 tokens at /4 and about 67,640 at /3. Output characters total 94,801. Recorded round durations sum to 1468.5 seconds. That sum covers the model call and the check that follows it in the same timer, and it does not split generation from simulation.

## Speed

Arithmetic intensity is flops divided by simulated HBM bytes. The published ridge is 222 Flops/Byte for bfloat16. The checks in `speed-report.txt` ran in float32, so 222 is the reference point. Reading each input once and writing the output once still leaves these shapes under 222. The level-3 ceiling is 19.7. The four level-4 ceilings are 28.4, 56.9, 42.7, and 73.1.

The optimized level-4 solve prints these DMA totals: 589,824 bytes (3 calls), 3,670,016 (20), 1,572,864 (9), and 7,340,032 (40). Those are the same counts as `reference_level4.py` in `speed-report.txt`. The two large shapes move 1.6× and 2.0× the byte floor, because tiles are loaded inside the K loop.

`level4_fast.py` is a separate kernel. It loads every lhs tile and every rhs tile into SBUF once, accumulates in one PSUM per output tile, and stores once. `python nkibench.py --level 4 --check level4_fast.py` is numerically 4/4 and at 1.00× the floor on all four shapes (28.4, 56.9, 42.7, 73.1). The level 1–3 reference kernels are already at the byte floor. That file is the traffic measurement. It is not the kernel the optimized agent submitted.

## Scoring and what was not run

`nkibench.py` runs static rules, then `nki.simulate`, then the HBM check. Numeric tolerance is `tol=2e-2`: worst absolute error divided by the RMS of the reference, at most 0.02. Level 2 in the optimized agent adds an exact-match check on top of that. Shapes are in `reproduction.md`.

`--all` runs levels 1 to 4. Levels 5 to 7 are the same matmul shapes with traffic bars of 1.6×, 1.25×, and 1.05×. Level 8 is single-head attention. Neither agent run entered levels 5–8.
