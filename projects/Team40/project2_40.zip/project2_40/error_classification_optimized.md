# Error Classification Report

Source: seat-201, `run.log` and `attempts_four_backups.jsonl`. Snapshot: 2026-10-10 17:37:48 EDT.

## Results and Counting Method

Of 100 candidates, 71 passed and 29 failed, giving a candidate failure rate of 29%. All four levels ultimately passed in all 5 runs, so the candidate failure rate is not the level failure rate. Success refers only to the original checker's existing simulator tests; it does not establish correctness on hidden inputs, generalization, or actual device performance.

| Level | Candidates | Passed candidates | Failed candidates | Successful runs |
|---|---:|---:|---:|---:|
| Level 1 | 40 | 20 | 20 | 5/5 |
| Level 2 | 20 | 20 | 0 | 5/5 |
| Level 3 | 20 | 11 | 9 | 5/5 |
| Level 4 | 20 | 20 | 0 | 5/5 |

## Error Categories

| Category | Level | Count | Share of failed candidates | Observed issue |
|---|---|---:|---:|---|
| Undefined variable | Level 1 | 20 | 69.0% | Code uses p, but the parameter is pool_size and p is not bound |
| DMA element count mismatch | Level 3 | 9 | 31.0% | Source has 8192 elements; destination has 16384 |

### Undefined Variable: Level 1

The variable `p` is undefined when constructing the `tile.ap(...)` access pattern. The logs identify candidate lines 18 and 20; both are grouped under the same root cause. The prompt uses p to denote the pooling window, but the generated code does not bind it to pool_size, which is consistent with the observed error.

```text
0 of 4 shapes passed. On C,H,W=(32, 32, 32) pool=2: raised NameError: name 'p' is not defined Candidate line 18: view = tile.ap([[H*W, C], [p*W, H//p], [p, W//p], [W, p], [1, p]]).  Check the pool-specific API card and fix the named operation first.
```

Suggested feedback improvement: explicitly require binding the window variable to the function parameter, or consistently using the parameter name. A static name check could also intercept this error before simulation.

### DMA Element Count Mismatch: Level 3

The error occurs when copying lhsT into lhs_tile. The source and destination element counts differ. The buffer size should be derived from the corresponding input shape, rather than another input or the output shape.

```text
0 of 1 shapes passed. On K=128 M=64 N=512: raised AssertionError: dma_copy requires src and dst to have the same number of elements, got src=8192, dst=16384 Candidate line 10: nisa.dma_copy(dst=lhs_tile, src=lhsT).  Match input SBUF buffers to each input shape. Match PSUM, result SBUF and output to (M,N). Do not copy an input into a result-sized buffer.
```

## Failures by Run

| Run | Level 1: undefined variable | Level 3: DMA mismatch | Total |
|---|---:|---:|---:|
| 1 | 4 | 2 | 6 |
| 2 | 4 | 2 | 6 |
| 3 | 4 | 1 | 5 |
| 4 | 4 | 3 | 7 |
| 5 | 4 | 1 | 5 |

## Record Limitations

- The source JSONL has no run/sample fields. This report infers them by aligning run order in the text log with consecutive level/round batches in the JSONL. All 25 batches were checked, each containing 4 candidates. The individual error records explicitly mark these fields as inferred.
- Only recorded failures are classified. The grading function retains only the first failing case in its feedback, so this report does not enumerate every error in each candidate.
- No syntax errors, nonexistent APIs, numerical mismatches, or other failure categories were recorded. This does not establish that they cannot occur on other inputs.
- The server files were retained during copying. No processes were stopped, and neither the model nor the Agent was modified.

Individual error records are in `error_classification.jsonl` in the same directory. The `jsonl_line` field identifies the line in the source JSONL.
