"""
Level 4 matmul that keeps the same numbers and drops the repeated HBM reads.

The tiled tutorial kernel reloads a lhs tile for every N tile and a rhs tile for
every M tile. Here each input tile is copied in once, nc_matmul accumulates in
one PSUM tile, and each result tile is stored once. On the level-4 shapes that
is the byte floor. The floor is still under the 222 ridge, so the kernel stays
memory bound. That is the shape, not a leftover reload.

    python nkibench.py --level 4 --check level4_fast.py
"""

import nki
import nki.isa as nisa
import nki.language as nl
from nki.typing import tensor


@nki.jit
def nki_matmul_tiled_(lhsT: tensor, rhs: tensor):
    K, M = lhsT.shape
    K_, N = rhs.shape
    assert K == K_, "lhsT and rhs must have the same contraction dimension"

    TILE_M = nl.tile_size.gemm_stationary_fmax  # 128
    TILE_K = nl.tile_size.pmax                  # 128
    TILE_N = nl.tile_size.gemm_moving_fmax      # 512

    assert M % TILE_M == 0
    assert N % TILE_N == 0
    assert K % TILE_K == 0

    num_m = M // TILE_M
    num_n = N // TILE_N
    num_k = K // TILE_K

    result = nl.ndarray((M, N), dtype=lhsT.dtype, buffer=nl.shared_hbm)

    # One SBUF tile per input block. The later matmul only reads these.
    lhs_tiles = []
    for k in range(num_k):
        row = []
        for m in range(num_m):
            tile = nl.ndarray((TILE_K, TILE_M), dtype=lhsT.dtype, buffer=nl.sbuf)
            nisa.dma_copy(dst=tile,
                          src=lhsT[k * TILE_K:(k + 1) * TILE_K,
                                   m * TILE_M:(m + 1) * TILE_M])
            row.append(tile)
        lhs_tiles.append(row)

    rhs_tiles = []
    for k in range(num_k):
        row = []
        for n in range(num_n):
            tile = nl.ndarray((TILE_K, TILE_N), dtype=rhs.dtype, buffer=nl.sbuf)
            nisa.dma_copy(dst=tile,
                          src=rhs[k * TILE_K:(k + 1) * TILE_K,
                                  n * TILE_N:(n + 1) * TILE_N])
            row.append(tile)
        rhs_tiles.append(row)

    for m in range(num_m):
        for n in range(num_n):
            # Outside K, so each K block adds into the same tile.
            acc = nl.ndarray((TILE_M, TILE_N), dtype=nl.float32, buffer=nl.psum)
            for k in range(num_k):
                nisa.nc_matmul(dst=acc,
                               stationary=lhs_tiles[k][m],
                               moving=rhs_tiles[k][n])
            out = nl.ndarray((TILE_M, TILE_N), dtype=result.dtype, buffer=nl.sbuf)
            nisa.tensor_copy(dst=out, src=acc)
            nisa.dma_copy(dst=result[m * TILE_M:(m + 1) * TILE_M,
                                     n * TILE_N:(n + 1) * TILE_N],
                          src=out)

    return result
