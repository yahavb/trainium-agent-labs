# Token Usage Report

Source: seat-201, `run.log` and `attempts_four_backups.jsonl`. Snapshot: 2026-10-10 17:37:48 EDT.

**Actual token usage cannot be recovered from these records.** The JSONL stores only `prompt_chars` and `reply_chars`, without the model API's prompt, completion, or total token counts. The text log also lacks these fields. Missing usage does not mean zero usage.

## Experiment Size

- Model: Qwen/Qwen3-8B; endpoint: localhost:8000/v1 inside the Pod.
- 5 runs, each testing Levels 1–4, with 4 candidates per round.
- 25 rounds and 100 candidates in total: Level 1 used 2 rounds per run; every other level used 1 round per run.
- 71 candidates passed and 29 failed. All four levels ultimately passed in 5/5 runs.
- Recorded round durations total 1468.5 seconds, approximately 24.48 minutes. This sum excludes some overhead between stages and cannot separate generation, checking, and simulation time.

## Recorded Character Counts

| Level | Candidates | Input characters | Output characters | Total characters |
|---|---:|---:|---:|---:|
| Level 1 | 40 | 87,380 | 39,369 | 126,749 |
| Level 2 | 20 | 35,060 | 14,080 | 49,140 |
| Level 3 | 20 | 36,040 | 18,272 | 54,312 |
| Level 4 | 20 | 44,340 | 23,080 | 67,420 |
| Total | 100 | 202,820 | 94,801 | 297,621 |

Each round sends the prompt to four candidates, so input characters count all four requests without deduplication. Output counts cover model replies, rather than only the extracted kernel code.

## Rough Token Estimates

For an approximate scale, each request is estimated using `ceil(characters/4)` and `ceil(characters/3)`. The original Agent used the latter rule for input budgeting. These estimates are not a confidence interval and are not guaranteed to contain the actual token count.

| Level | Input estimate: chars/4 / chars/3 | Output estimate: chars/4 / chars/3 | Total estimate: chars/4 / chars/3 |
|---|---:|---:|---:|
| Level 1 | 21,860 / 29,140 | 9,870 / 13,125 | 31,730 / 42,265 |
| Level 2 | 8,780 / 11,700 | 3,520 / 4,700 | 12,300 / 16,400 |
| Level 3 | 9,020 / 12,020 | 4,568 / 6,101 | 13,588 / 18,121 |
| Level 4 | 11,100 / 14,780 | 5,780 / 7,700 | 16,880 / 22,480 |
| Total | 50,760 / 67,640 | 23,738 / 31,626 | 74,498 / 99,266 |

These estimates exclude chat templates, special tokens, unrecorded hidden reasoning, and requests absent from the JSONL. The source records lack `finish_reason` and thinking settings, so they cannot fully establish whether truncation or hidden reasoning occurred.

## Round Durations by Level

| Level | Rounds | Total duration (seconds) | Average per round (seconds) |
|---|---:|---:|---:|
| Level 1 | 10 | 572.5 | 57.2 |
| Level 2 | 5 | 221.1 | 44.2 |
| Level 3 | 5 | 290.0 | 58.0 |
| Level 4 | 5 | 384.9 | 77.0 |

## Recording Accurate Usage in Future Runs

Save `usage.prompt_tokens`, `usage.completion_tokens`, and `usage.total_tokens` from each model response to the JSONL for each candidate. Mark missing fields as unavailable. Measure model requests, static checking, and simulator validation separately. Preparing this report did not modify the Agent.
