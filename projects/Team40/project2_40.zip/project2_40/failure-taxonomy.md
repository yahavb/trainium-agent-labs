# Failure taxonomy

Source: the five-run log in `run.log`, with every sample counted from the matching 200 records at the end of `attempts.jsonl` (4 samples × 50 rounds). A round's printed line is the best of those 4. Reward weights are parses 0.1, rules 0.2, runs 0.2, correct 0.5.

Every level solved on every run (5/5). The failures below are the attempts before that solve. 80 of 200 samples scored 1.00. The other 120 are classified here. None of them is a parse error, an empty answer, or a context truncation.

## What the loop actually did

Each run followed the same path. The best sample is what the next prompt was built from.

| Level | Round | Best score | Runs | What the best sample did | Next round |
|---|---|---|---|---|---|
| 1 | 0 | 0.30 | 5/5 | `dma_copy` of the 2×2 window (`src=4`) into the full tile (`dst=16384`) | recipe for the whole-tensor reduction |
| 1 | 1 | 0.30 | 5/5 | called `nisa.multiply`, which does not exist | recipe names `nisa.tensor_scalar(..., op0=nl.multiply)` |
| 1 | 2 | 1.00 | 5/5 | correct on all 4 shapes | stop |
| 2 | 0 | 0.30 | 5/5 | `dma_copy` sides differ in length | recipe: output stays `(P, F)`, copy with `nl.ds` |
| 2 | 1 | 1.00 | 5/5 | correct on all 4 shapes | stop |
| 3 | 0 | 0.30 | 5/5 | 4 runs: `dma_copy` size mismatch. 1 run: a 1-D SBUF/PSUM tile | recipe: one `nc_matmul`, output `(M, N)` |
| 3 | 1 | 1.00 | 5/5 | correct. Last shape reports 19.7 Flops/Byte | stop |
| 4 | 0 | 0.62 or 0.50 | 4 runs at 0.62, 1 run at 0.50 | 0.62: partition 256 exceeds 128, and the K=128 shape still passes (1/4). 0.50: the kernel ran and every checked element missed tolerance 0.02 | recipe: tiles of 128, one PSUM outside the K loop |
| 4 | 1 | 0.10 | 5/5 | the rewrite dropped the entry name `nki_matmul_tiled_`, so the rule check scored zero | same recipe, entry name included |
| 4 | 2 | 1.00 | 5/5 | correct on all 4 shapes. Last shape reports 36.6 Flops/Byte | stop |

0.30 means the file parsed and passed the static rules, then `nki.simulate` raised. 0.50 means it ran and zero shapes were inside tolerance. 0.62 is 0.625 printed to two decimals: runs, plus one of the four shapes numerically correct. 0.10 means it parsed and failed the rule check.

## Every wrong sample

Counts are samples, not rounds. A solved round contributes nothing to this table.

| Mode | Level | Samples | Score | What it is |
|---|---|---|---|---|
| Copied the pool window | 1, round 0 | 20 | 0.30 | `pool_size` is the integer 2. The 4-element copy is the 2×2 window, not that integer. The destination tile is the whole input. |
| Invented `nisa.multiply` | 1, round 1 | 20 | 0.30 | After the reduction is right, the model invents a scale op. The real call is `nisa.tensor_scalar` with `op0=nl.multiply`. |
| Transpose `dma_copy` size mismatch | 2, round 0 | 18 | 0.30 | The two sides of `dma_copy` have different numbers of elements. The output of this level stays `(P, F)`. |
| Called `.transpose` on an NKI tensor | 2, round 0 | 1 | 0.30 | `NkiTensor` has no `.transpose`. |
| Bad transpose index | 2, round 0 | 1 | 0.30 | A length-12 vector was written into a 1536-element view. |
| Matmul `dma_copy` size mismatch | 3, round 0 | 11 | 0.30 | Operand tile and `dma_copy` length disagree on the single tile K=128, M=64, N=512. |
| 1-D tile | 3, round 0 | 9 | 0.30 | SBUF and PSUM need a partition axis and a free axis. A 1-D `nl.ndarray` is illegal. |
| Partition axis above 128 | 4, round 0 | 8 | 0.62 | A tile's first dimension is 256. The K=128 shape still passes, which is why the score is 0.62 rather than 0.30. |
| Tiling index broadcast | 4, round 0 | 11 | 0.30 | `ValueError`: a value of shape `(65536,)` cannot be written into an index of shape `(16384,)`. |
| Numerical mismatch | 4, round 0 | 1 | 0.50 | Ran. Worst error 324× the output RMS, tolerance 0.02, 100% of elements outside tolerance. This was run 4's best sample. |
| Renamed the entry point | 4, round 1 | 20 | 0.10 | No function named `nki_matmul_tiled_`. The repair rewrote a kernel that had already run, and the new name failed the rule check. |

## What did not happen

The give-up rule (4 identical feedback strings) never fired. No level stopped early. No sample returned prose instead of code. Levels 5–8 were not in this run: `agent.py --all` stops at level 4, and those levels have no reference kernel in the repo.
