#!/usr/bin/env python3
"""Agent assembled from the four original per-level backup files.
Each level retains its original prompts, checker, feedback and generation loop.
Use --all for levels 1-4 or --level N for one; --repeat controls run count.
"""
import argparse
import ast
import json
import os
import re
import sys
import textwrap
import time
import numpy as np
import nkibench


# Level 1: preserved from agent.level1.20261010-134433.py
MODEL_1 = os.environ.get("KERNEL_AGENT_MODEL", "Qwen/Qwen3-8B")

MIN_ANSWER_TOKENS_1 = 2500

REASONING_KEYS_1 = ("reasoning", "reasoning_content")

WEIGHTS_1 = dict(parses=0.1, rules=0.2, runs=0.2, correct=0.5)

def pool_api_violations_1(source):
    """Add precise feedback for known API mistakes and aliased framework shortcuts."""
    tree = ast.parse(source)
    aliases = {}
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            for alias in node.names:
                aliases[alias.asname or alias.name.split('.')[0]] = (
                    alias.name if alias.asname else alias.name.split('.')[0])
        elif isinstance(node, ast.ImportFrom) and node.module:
            for alias in node.names:
                aliases[alias.asname or alias.name] = node.module + '.' + alias.name
    fixes = {
        'nki.isa.reduce_sum': 'Use nl.sum(window_view, axis=[3,4]) for the 5-D pool view described in the API card.',
        'nki.isa.add': 'Do not accumulate pool elements with nisa.add; use nl.sum over the window axes.',
        'nki.isa.multiply': 'Scale the sum with nisa.tensor_scalar(dst=..., data=..., op0=nl.multiply, operand0=1.0/(p*p)).',
        'nki.isa.scalar_mul': 'Scale the sum with nisa.tensor_scalar(dst=..., data=..., op0=nl.multiply, operand0=1.0/(p*p)).',
    }
    bad = []
    for node in ast.walk(tree):
        if not isinstance(node, ast.Call):
            continue
        dotted = ast.unparse(node.func)
        head, dot, tail = dotted.partition('.')
        resolved = aliases.get(head, head) + (dot + tail if dot else '')
        if resolved in fixes:
            bad.append(f'line {node.lineno}: `{dotted}` is not the pooling API to use. {fixes[resolved]}')
        elif (resolved.split('.')[0] in {'numpy', 'torch', 'jax', 'np', 'jnp', 'F', 'nn'}
              and resolved.split('.')[-1] in nkibench.LEVELS[1]['banned']):
            bad.append(f'line {node.lineno}: prohibited framework shortcut `{dotted}`. '
                       'Replace it with the NKI window-view reduction and scaling shown in the API card.')
    return bad

def grade_1(source, level):
    """Returns (reward, parts, feedback). Feedback is an INSTRUCTION, never just a verdict."""
    parts = dict(parses=False, rules=False, runs=False, correct=False)
    if not source.strip():
        return 0.0, parts, ("No code came back. Reply with one python code block containing the "
                            "kernel and nothing else.")
    try:
        compile(source, "<candidate>", "exec")
        parts["parses"] = True
    except SyntaxError as e:
        return (WEIGHTS_1["parses"] * 0, parts,
                f"The code does not parse: {e.msg} on line {e.lineno}. Send one complete python "
                f"code block.")
    violations = pool_api_violations_1(source) + nkibench.check_rules(source, level)
    if violations:
        extra = ""
        if any("no function named" in v for v in violations):
            # Measured: this repeated 15 rounds running, because "there is no function named X"
            # never said what the function should look like. Hand over the exact line.
            import inspect
            ref = nkibench.LEVELS[level]["ref"]
            args = ", ".join(inspect.signature(ref).parameters)
            extra = (f" Start the function with exactly this line:  "
                     f"def {nkibench.LEVELS[level]['entry']}({args}):  "
                     f"and put @nki.jit on the line above it.")
        return (sum(WEIGHTS_1[k] for k, v in parts.items() if v), parts,
                "Rule violations, which score zero however fast the kernel is. Fix exactly "
                "these: " + " ".join(violations) + extra)
    parts["rules"] = True
    spec = nkibench.LEVELS[level]
    path = f"/tmp/_agent_level{level}.py"
    with open(path, "w") as f:
        f.write(source)
    try:
        kernel = nkibench.load_kernel(path, spec["entry"])
    except ModuleNotFoundError as e:
        # Two very different causes, and conflating them aborted a whole run: either the SDK is
        # absent (an environment problem the model cannot fix), or the model imported a module it
        # invented -- observed: `import nki.nl`. Tell them apart by asking whether nki itself is
        # importable.
        try:
            import nki  # noqa: F401
            sdk_present = True
        except ImportError:
            sdk_present = False
        if not sdk_present:
            raise SystemExit(
                f"cannot import {e.name!r}, so no NKI kernel can be loaded here. Run this where "
                f"the Neuron SDK exists -- k8s/kernel-agent-job.yaml does that -- or use "
                f"--offline to exercise the loop without a kernel ever running.") from e
        return (sum(WEIGHTS_1[k] for k, v in parts.items() if v), parts,
                f"There is no module named {e.name!r}. The only imports that exist are: "
                f"`import nki`, `import nki.language as nl`, and `import nki.isa as nisa`. "
                f"Use exactly those three.")
    except Exception as e:
        return (sum(WEIGHTS_1[k] for k, v in parts.items() if v), parts,
                f"The file imports but {spec['entry']} could not be loaded: "
                + enrich_1(f"{type(e).__name__}: {e}", source, e))
    failures, passed, intensity = [], 0, None
    for case in spec["shapes"]:
        args, _ = nkibench.make_inputs(case, level)
        before = [x.copy() if isinstance(x, np.ndarray) else x for x in args]
        want = spec["ref"](*args)
        try:
            got, counted = nkibench.simulate_and_count(kernel, args)
        except nkibench.NkiMissing as e:
            return (sum(WEIGHTS_1[k] for k, v in parts.items() if v), parts,
                    f"CANNOT SIMULATE: {e}")
        except Exception as e:
            failures.append((nkibench.label(case, level),
                             enrich_1(f"raised {type(e).__name__}: {e}", source, e)))
            continue
        parts["runs"] = True
        m = (nkibench.check_inputs_untouched(before, args)
             or nkibench.describe_mismatch(got, want)
             or nkibench.check_traffic_bar(level, counted, args, want))
        # A simulator warning about a hardware-correctness hazard counts as a failure even when the
        # numbers happen to match on CPU: the kernel would be wrong on the device.
        hazards = [w for w in counted.get("warnings", [])
                   if "incorrect results on hardware" in w]
        if hazards and not m:
            m = ("CORRECT ON CPU BUT WRONG ON HARDWARE: " + hazards[0]
                 + ". Fix that before anything else -- the simulator agrees with the reference here "
                   "and the device would not.")
        if m:
            failures.append((nkibench.label(case, level), m))
            continue
        passed += 1
        if level >= 3 and counted["bytes"]:
            intensity = nkibench.roofline(
                nkibench.matmul_flops(case["M"], case["K"], case["N"]), counted["bytes"])
    if failures:
        lbl, first = failures[0]
        return (sum(WEIGHTS_1[k] for k, v in parts.items() if v)
                + WEIGHTS_1["correct"] * passed / len(spec["shapes"]), parts,
                f"{passed} of {len(spec['shapes'])} shapes passed. On {lbl}: {first}")

    parts["correct"] = True
    reward = sum(WEIGHTS_1.values())
    note = "Correct on every shape."
    if intensity:
        note += " " + nkibench.explain_roofline(intensity)
    return reward, parts, note

API_CARD_1 = """Pool-specific NKI usage (from reference_level1.py):
import nki; import nki.language as nl; import nki.isa as nisa
Allocate with nl.ndarray(shape, dtype=x.dtype, buffer=nl.sbuf).
Use nl.shared_hbm for a NEW output. Never overwrite the input.
nisa.dma_copy(dst=tile, src=x): both operands must contain the same number of elements.
The first (channel/partition) dimension must be <=128. Derive sizes from x.shape.
For x shaped (C,H,W), window p, output is (C,H//p,W//p).
Group windows with a strided view, then reduce the two WINDOW axes, not channels.
For a loaded tile with the original (C,H,W) layout, this access pattern groups windows:
view = tile.ap([[H*W,C], [p*W,H//p], [p,W//p], [W,p], [1,p]])
summed = nl.sum(view, axis=[3,4])
scaled = nl.ndarray(summed.shape, dtype=summed.dtype, buffer=nl.sbuf)
nisa.tensor_scalar(dst=scaled, data=summed, op0=nl.multiply, operand0=1.0/(p*p))
Finally dma_copy scaled to the output in shared_hbm and return the output.
nl.multiply above is an operator argument, not nisa.multiply or nisa.add.
Do not invent nisa.reduce_sum, nisa.add, nisa.multiply, or nisa.scalar_mul.
Do not use NumPy/PyTorch whole-operation mean/pooling shortcuts. NKI reductions are allowed.
"""

def available_names_1(dotted):
    """Never recommend functions by spelling similarity: semantics are what matter."""
    return (f' `{dotted}` does not exist. Do not guess a similarly spelled function. '
            'Use the verified pooling operations in the API card, or rewrite that computation.')

def real_signature_1(func_name):
    """The actual signature of an NKI function, for when the model invents arguments."""
    import inspect
    for mod_name in ("nki.language", "nki.isa", "nki"):
        try:
            mod = __import__(mod_name, fromlist=["x"])
        except Exception:
            continue
        fn = getattr(mod, func_name, None)
        if fn is None:
            continue
        try:
            return f"{mod_name.split('.')[-1]}.{func_name}{inspect.signature(fn)}"
        except (TypeError, ValueError):
            return f"{mod_name.split('.')[-1]}.{func_name}"
    return ""

def enrich_1(error_text, source='', error=None):
    location = ''
    tb = getattr(error, '__traceback__', None)
    while tb:
        if '_agent_level' in tb.tb_frame.f_code.co_filename:
            lines = source.splitlines()
            line = lines[tb.tb_lineno - 1] if tb.tb_lineno <= len(lines) else ''
            location = f' Candidate line {tb.tb_lineno}: {line.strip()[:180]}. '
        tb = tb.tb_next
    prefix = error_text + location
    if 'same number of elements' in error_text:
        return prefix + (' Match the destination buffer to the ACTUAL source slice, not a fixed tile size. '
                         'For a p-by-p window across C channels the source and destination both '
                         'contain C*p*p elements. For a whole input tile use the input shape. '
                         'Fix this copy and its allocation before changing the pooling arithmetic.')
    if 'partition dimension' in error_text and 'exceeds' in error_text:
        return prefix + (' The channel dimension of each SBUF tile must be <=128. '
                         'Process channels in chunks and use the same channel slice for output.')
    if 'must have at least 2 dimensions' in error_text:
        return prefix + ' Keep a channel/partition axis plus free axes; pool input tiles can have shape (C,H,W).'
    if 'cannot reshape array of size' in error_text:
        return prefix + ' Preserve element counts; use the window access-pattern view in the API card instead of guessing a reshape.'
    if "'MemoryRegion' object is not callable" in error_text:
        return prefix + ' Allocate with nl.ndarray(shape, dtype=..., buffer=nl.sbuf); do not call nl.sbuf.'
    match = re.search(r"(\w+)\(\) got an unexpected keyword argument '(\w+)'", error_text)
    if match:
        signature = real_signature_1(match.group(1))
        return prefix + f' Remove unsupported argument `{match.group(2)}`.' + (f' Installed signature: {signature}.' if signature else '')
    if 'has no attribute' in error_text:
        return prefix + ' Use nl.sum for pool-window reduction and nisa.tensor_scalar with op0=nl.multiply for scaling. Do not guess API names.'
    return prefix + ' Check the pool-specific API card and fix the named operation first.'

def first_prompt_1(level, terse=0):
    if level != 1:
        raise ValueError('This version enables level 1 only.')
    entry = nkibench.LEVELS[1]['entry']
    return (
        f'Write a complete NKI average-pooling kernel: @nki.jit def {entry}(x, pool_size).\n'
        'Input x is float32 [C,H,W]; pool_size is a positive integer p. '
        'Return [C,H//p,W//p], averaging each non-overlapping p-by-p window. '
        'Ignore incomplete windows at the right/bottom; do not modify x.\n'
        'Use this order: allocate/load, group windows, sum and scale, store/return.\n'
        + API_CARD_1 + '\nReturn one complete Python code block, no prose.'
    )

def repair_prompt_1(level, source, feedback):
    # Keep the working code whole; oversized candidates are regenerated, never silently sliced.
    task = f'Repair the NKI average-pooling kernel `{nkibench.LEVELS[1]["entry"]}`.\n'
    if len(source) > 10000:
        return first_prompt_1(1) + '\nRewrite concisely; previous failure:\n' + feedback[:1800]
    return (
        task + 'Input [C,H,W], output [C,H//p,W//p], each output averages its p-by-p window.\n'
        + API_CARD_1 + '\nPrevious candidate:\n```python\n' + source + '\n```\n'
        + 'Checker feedback:\n' + feedback[:1800] + '\n'
        'Fix the reported issue first; related buffer/loop changes are allowed. '
        'Preserve already-correct behavior. Return one complete concise Python code block, no prose.'
    )

CODE_BLOCK_1 = re.compile(r"```(?:python)?\s*(.*?)```", re.S)

def extract_code_1(text):
    """Pull out the code, and return NOTHING rather than prose.
    The old fallback returned the whole reply whenever it contained "def ", so a numbered list
    or a sentence reached the compiler and produced "invalid decimal literal on line 2" -- a
    parse error that blamed the model for the extractor's mistake.
    """
    text = text or ""
    blocks = CODE_BLOCK_1.findall(text)
    if blocks:
        return max(blocks, key=len).strip()
    # No fence: start at the first line that can legally begin a module and keep the rest.
    lines = text.splitlines()
    for i, line in enumerate(lines):
        if re.match(r"^\s*(import |from |@nki|def )", line):
            return "\n".join(lines[i:]).strip()
    return ""

def ask_1(a, prompt):
    import httpx
    # enable_thinking=False matters. Qwen3 reasons before answering, and with thinking on it
    # spent the whole budget there: the first cluster run returned "No code came back" at 54.7s
    # over and over, plus truncated fragments (invalid decimal literal, unterminated string).
    # Keep prompt + answer inside the server's context, or the answer is silently cut off and
    # every parse error below is really a budget error. Repair prompts grow with the kernel.
    # Conservative character estimate; still not an exact tokenizer count.
    est_prompt = (len(prompt) + 2) // 3
    remaining = a.context - est_prompt - 256
    if remaining < 256:
        raise SystemExit("Prompt exceeds the safe context budget; shorten the candidate/feedback.")
    budget = min(a.max_tokens, remaining)
    if budget < a.max_tokens:
        print(f"    (prompt is ~{est_prompt} tokens, so the answer budget is capped at {budget} "
              f"to stay inside the {a.context}-token context)")
    body = dict(model=a.model, messages=[{"role": "user", "content": prompt}],
                max_tokens=budget, temperature=0.6, top_p=0.95,
                chat_template_kwargs={"enable_thinking": a.think})
    r = httpx.post(f"{a.base.rstrip('/')}/chat/completions", json=body,
                   timeout=900, verify=False)
    if r.status_code != 200:
        raise SystemExit(f"the endpoint returned HTTP {r.status_code}:\n{r.text[:600]}")
    payload = r.json()
    ch = payload["choices"][0]
    msg = ch.get("message", {})
    reasoning = next((msg[k] for k in REASONING_KEYS_1 if msg.get(k)), "")
    content = msg.get("content") or ""
    finish = ch.get("finish_reason")
    if finish == "length":
        # Do not let a budget problem look like a model failure.
        print(f"    (TRUNCATED: finish_reason=length after {len(content)} chars. The answer was "
              f"cut off, so any parse error below is the budget, not the model. Prompt is "
              f"{len(prompt)} chars; server context is the ceiling.)")
    if not content.strip() and reasoning:
        # The single most common surprise on this endpoint, so name it rather than reporting
        # an empty answer as a model failure.
        print(f"    (empty answer, {len(reasoning)} chars of hidden reasoning, "
              f"finish={ch.get('finish_reason')} — shorten the prompt rather than raising the "
              f"budget)")
    return content

def ask_parallel_1(a, prompt, n):
    import concurrent.futures as cf
    with cf.ThreadPoolExecutor(max_workers=n) as ex:
        return [f.result() for f in [ex.submit(ask_1, a, prompt) for _ in range(n)]]

def offline_answers_1(level, n, rnd):
    """No model. Replays the shipped reference, preceded by a deliberately broken version, so the
    loop and the feedback path can be exercised with no endpoint. Never report a number."""
    ref = open(f"reference_level{level}.py").read()
    if rnd == 0:
        broken = ref.replace("@nki.jit", "", 1)
        return [f"```python\n{broken}\n```"] * n
    return [f"```python\n{ref}\n```"] * n

def solve_1(a, level, log):
    print(f"\n=========== level {level}: {nkibench.LEVELS[level]['op']} ===========")
    terse = a.terse
    prompt = first_prompt_1(level, terse)
    best = (0.0, None, "")
    tried, streak, seen = [], 0, {}
    latest = ("", "")
    for rnd in range(a.rounds):
        t0 = time.perf_counter()
        replies = (offline_answers_1(level, a.samples, rnd) if a.offline
                   else ask_parallel_1(a, prompt, a.samples))
        graded = []
        for reply in replies:
            src = extract_code_1(reply)
            reward, parts, feedback = grade_1(src, level)
            graded.append((reward, src, feedback, parts))
            log.write(json.dumps(dict(level=level, round=rnd, reward=reward, parts=parts,
                                      prompt_chars=len(prompt), reply_chars=len(reply),
                                      code=src, feedback=feedback)) + "\n")
        log.flush()
        graded.sort(key=lambda g: g[0], reverse=True)
        top = graded[0]
        if top[0] > best[0]:
            best = (top[0], top[1], top[2])
        # Repair the LATEST attempt, not the best one. Rebuilding from the best attempt with the
        # best attempt's feedback is a fixed point: once a round scores worse, the prompt stops
        # changing, and a greedy model then returns the same answer forever. Measured: level 2
        # stuck at 0.10 for four rounds while the prompt still carried the 0.50 code.
        if (top[1] or "").strip():
            latest = (top[1], top[2])
        same = top[2] == (tried[-1] if tried else None)
        if same:
            # Collapse. Fifteen identical multi-line blocks is noise, not information.
            print(f"round {rnd}: same failure again ({top[0]:.2f}, best so far {best[0]:.2f})")
        else:
            print(f"round {rnd}: this round {top[0]:.2f}  best so far {best[0]:.2f}  "
                  f"({time.perf_counter() - t0:.1f}s)")
            print(f"  {top[2][:400]}")
        if top[0] >= sum(WEIGHTS_1.values()) - 1e-9:
            print(f"  SOLVED on round {rnd}. {top[2]}")
            print("  ---------------- the kernel ----------------")
            print(textwrap.indent(top[1], "  "))
            print("  -------------------------------------------")
            return top[0], rnd + 1
        seen[top[2]] = seen.get(top[2], 0) + 1
        streak = streak + 1 if same else 1
        if seen[top[2]] >= a.give_up_after:
            how = ("the identical failure %d rounds running" % streak if streak >= a.give_up_after
                   else "this failure for the %dth time, alternating with %d other(s)"
                        % (seen[top[2]], len(seen) - 1))
            print(f"  STOPPING this level: {how}. The agent is cycling between a fixed set of "
                  f"mistakes rather than converging, so more rounds will not help. Failures seen:")
            for f, n in sorted(seen.items(), key=lambda kv: -kv[1]):
                print(f"    {n}x  {f[:110]}")
            return best[0], rnd + 1
        tried.append(top[2])
        repeats = streak
        if repeats >= 2 and (best[1] or "").strip():
            # Sampling on this endpoint is greedy, so an unchanged prompt returns an unchanged
            # answer. Measured: the same TypeError 19 rounds running. Changing the prompt is the
            # only thing that can change the answer, so say what has already been tried.
            ledger = "\n".join(f"- {t[:160]}" for t in list(dict.fromkeys(tried))[-2:])
            prompt = (repair_prompt_1(level, latest[0], latest[1])
                      + f"\n\nThese approaches have already failed, so do something different:\n"
                        f"{ledger}")
            print(f"  same failure {repeats}x — adding a ledger of {len(set(tried))} failed "
                  f"attempts to break the repeat")
            continue
        if not (latest[0] or "").strip():
            # Nothing came back to repair. Asking it to "fix" an empty code block produced a
            # 202-character prompt and, under greedy sampling, the identical non-answer six
            # rounds running. Shorten and re-ask instead.
            terse = min(terse + 1, 2)
            prompt = first_prompt_1(level, terse)
            print(f"  no code yet, so re-asking with a shorter prompt (terseness {terse})")
        else:
            prompt = repair_prompt_1(level, latest[0], latest[1])
    print(f"  not solved in {a.rounds} rounds; best reward {best[0]:.2f}")
    return best[0], a.rounds


# Level 2: preserved from agent.level2.20261010-135232.py
MODEL_2 = os.environ.get("KERNEL_AGENT_MODEL", "Qwen/Qwen3-8B")

MIN_ANSWER_TOKENS_2 = 2500

REASONING_KEYS_2 = ("reasoning", "reasoning_content")

WEIGHTS_2 = dict(parses=0.1, rules=0.2, runs=0.2, correct=0.5)

def transpose_api_violations_2(source):
    """Recognize aliased framework shortcuts and unsafe direct HBM assignments."""
    tree = ast.parse(source)
    aliases, hbm_outputs = {}, set()
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            for alias in node.names:
                aliases[alias.asname or alias.name.split('.')[0]] = (
                    alias.name if alias.asname else alias.name.split('.')[0])
        elif isinstance(node, ast.ImportFrom) and node.module:
            for alias in node.names:
                aliases[alias.asname or alias.name] = node.module + '.' + alias.name
    def resolve(node):
        dotted = ast.unparse(node)
        head, dot, tail = dotted.partition('.')
        return aliases.get(head, head) + (dot + tail if dot else '')
    for node in ast.walk(tree):
        if isinstance(node, ast.Assign) and isinstance(node.value, ast.Call):
            if resolve(node.value.func) == 'nki.language.ndarray' and any(
                kw.arg == 'buffer' and resolve(kw.value) == 'nki.language.shared_hbm'
                for kw in node.value.keywords
            ):
                hbm_outputs.update(t.id for t in node.targets if isinstance(t, ast.Name))
    bad = []
    for node in ast.walk(tree):
        if isinstance(node, ast.Call):
            resolved = resolve(node.func)
            if (resolved.split('.')[0] in {'numpy', 'torch', 'jax', 'np', 'jnp', 'F', 'nn'}
                and resolved.split('.')[-1] in nkibench.LEVELS[2]['banned']):
                bad.append(f'line {node.lineno}: framework shortcut `{ast.unparse(node.func)}` is prohibited. '
                           'Reorder SBUF columns with nisa.tensor_copy and the index mapping in the API card.')
            if resolved in {'nki.isa.add', 'nki.isa.reduce_sum', 'nki.isa.multiply', 'nki.isa.scalar_mul'}:
                bad.append(f'line {node.lineno}: `{ast.unparse(node.func)}` is not needed or supported here. '
                           'Transpose only copies values: use nisa.tensor_copy, not arithmetic.')
        targets = []
        if isinstance(node, ast.Assign):
            targets = node.targets
        elif isinstance(node, (ast.AugAssign, ast.AnnAssign)):
            targets = [node.target]
        for target in targets:
            root = target
            while isinstance(root, ast.Subscript):
                root = root.value
            if isinstance(target, ast.Subscript) and isinstance(root, ast.Name) and root.id in hbm_outputs:
                bad.append(f'line {node.lineno}: direct assignment into HBM output `{root.id}`. '
                           'Reorder into an SBUF output tile, then store it using nisa.dma_copy.')
    return bad

def check_transpose_exact_2(got, want, case):
    """Transpose only moves values, so tolerance-based arithmetic checks are insufficient."""
    got = np.asarray(got)
    if got.shape != want.shape:
        return None  # Existing shape diagnostics handle this first.
    if got.dtype != want.dtype:
        return f'Transpose must preserve dtype: expected {want.dtype}, got {got.dtype}. Allocate output with x.dtype.'
    if np.array_equal(got, want):
        return None
    row, column = (int(v) for v in np.argwhere(got != want)[0])
    f1, f2 = case['shape2D']
    j, i = divmod(column, f1)
    return (f'TRANSPOSE INDEX MISMATCH at output row {row}, column {column}. '
            f'That position must copy input column {i*f2+j} from the SAME row. '
            'Use source=i*F2+j and destination=j*F1+i; copy values without arithmetic.')

def grade_2(source, level):
    """Returns (reward, parts, feedback). Feedback is an INSTRUCTION, never just a verdict."""
    if level != 2:
        raise ValueError("Only level 2 is enabled.")
    parts = dict(parses=False, rules=False, runs=False, correct=False)
    if not source.strip():
        return 0.0, parts, ("No code came back. Reply with one python code block containing the "
                            "kernel and nothing else.")
    try:
        compile(source, "<candidate>", "exec")
        parts["parses"] = True
    except SyntaxError as e:
        return (WEIGHTS_2["parses"] * 0, parts,
                f"The code does not parse: {e.msg} on line {e.lineno}. Send one complete python "
                f"code block.")
    violations = transpose_api_violations_2(source) + nkibench.check_rules(source, level)
    if violations:
        extra = ""
        if any("no function named" in v for v in violations):
            # Measured: this repeated 15 rounds running, because "there is no function named X"
            # never said what the function should look like. Hand over the exact line.
            import inspect
            ref = nkibench.LEVELS[level]["ref"]
            args = ", ".join(inspect.signature(ref).parameters)
            extra = (f" Start the function with exactly this line:  "
                     f"def {nkibench.LEVELS[level]['entry']}({args}):  "
                     f"and put @nki.jit on the line above it.")
        return (sum(WEIGHTS_2[k] for k, v in parts.items() if v), parts,
                "Rule violations, which score zero however fast the kernel is. Fix exactly "
                "these: " + " ".join(violations) + extra)
    parts["rules"] = True
    spec = nkibench.LEVELS[level]
    path = f"/tmp/_agent_level{level}.py"
    with open(path, "w") as f:
        f.write(source)
    try:
        kernel = nkibench.load_kernel(path, spec["entry"])
    except ModuleNotFoundError as e:
        # Two very different causes, and conflating them aborted a whole run: either the SDK is
        # absent (an environment problem the model cannot fix), or the model imported a module it
        # invented -- observed: `import nki.nl`. Tell them apart by asking whether nki itself is
        # importable.
        try:
            import nki  # noqa: F401
            sdk_present = True
        except ImportError:
            sdk_present = False
        if not sdk_present:
            raise SystemExit(
                f"cannot import {e.name!r}, so no NKI kernel can be loaded here. Run this where "
                f"the Neuron SDK exists -- k8s/kernel-agent-job.yaml does that -- or use "
                f"--offline to exercise the loop without a kernel ever running.") from e
        return (sum(WEIGHTS_2[k] for k, v in parts.items() if v), parts,
                f"There is no module named {e.name!r}. The only imports that exist are: "
                f"`import nki`, `import nki.language as nl`, and `import nki.isa as nisa`. "
                f"Use exactly those three.")
    except Exception as e:
        return (sum(WEIGHTS_2[k] for k, v in parts.items() if v), parts,
                f"The file imports but {spec['entry']} could not be loaded: "
                + enrich_2(f"{type(e).__name__}: {e}", source, e))
    failures, passed, intensity = [], 0, None
    dma_metrics = []
    for case in spec["shapes"]:
        args, _ = nkibench.make_inputs(case, level)
        before = [x.copy() if isinstance(x, np.ndarray) else x for x in args]
        want = spec["ref"](*args)
        try:
            got, counted = nkibench.simulate_and_count(kernel, args)
        except nkibench.NkiMissing as e:
            return (sum(WEIGHTS_2[k] for k, v in parts.items() if v), parts,
                    f"CANNOT SIMULATE: {e}")
        except Exception as e:
            failures.append((nkibench.label(case, level),
                             enrich_2(f"raised {type(e).__name__}: {e}", source, e)))
            continue
        parts["runs"] = True
        m = (nkibench.check_inputs_untouched(before, args)
             or nkibench.describe_mismatch(got, want)
             or check_transpose_exact_2(got, want, case)
             or nkibench.check_traffic_bar(level, counted, args, want))
        # A simulator warning about a hardware-correctness hazard counts as a failure even when the
        # numbers happen to match on CPU: the kernel would be wrong on the device.
        hazards = [w for w in counted.get("warnings", [])
                   if "incorrect results on hardware" in w]
        if hazards and not m:
            m = ("CORRECT ON CPU BUT WRONG ON HARDWARE: " + hazards[0]
                 + ". Fix that before anything else -- the simulator agrees with the reference here "
                   "and the device would not.")
        if m:
            failures.append((nkibench.label(case, level), m))
            continue
        passed += 1
        dma_metrics.append(f"{nkibench.label(case, level)}: "
                           f"{counted.get('bytes', 0)} DMA bytes, "
                           f"{counted.get('transfers', 0)} DMA calls"
                           + (" (byte count incomplete)" if counted.get("unmeasured") else ""))
        if level >= 3 and counted["bytes"]:
            intensity = nkibench.roofline(
                nkibench.matmul_flops(case["M"], case["K"], case["N"]), counted["bytes"])
    if failures:
        lbl, first = failures[0]
        return (sum(WEIGHTS_2[k] for k, v in parts.items() if v)
                + WEIGHTS_2["correct"] * passed / len(spec["shapes"]), parts,
                f"{passed} of {len(spec['shapes'])} shapes passed. On {lbl}: {first}")

    parts["correct"] = True
    reward = sum(WEIGHTS_2.values())
    note = "Correct on every shape; exact transpose values and dtype preserved."
    if dma_metrics:
        note += " Simulator DMA metrics (not device timings or SBUF copy counts): " + "; ".join(dma_metrics)
    if intensity:
        note += " " + nkibench.explain_roofline(intensity)
    return reward, parts, note

API_CARD_2 = """Transpose-only NKI usage, based on reference_level2.py:
import nki; import nki.language as nl; import nki.isa as nisa
Input x has shape (P,F1*F2), shape2D=(F1,F2). Output has EXACTLY x.shape.
Transpose the F1-by-F2 matrix INSIDE EACH partition row; do not transpose P.
For every row: out[:,j*F1+i] = x[:,i*F2+j]. P is unchanged.
Allocate input/output SBUF tiles with nl.ndarray(x.shape, dtype=x.dtype, buffer=nl.sbuf).
Allocate a NEW HBM output with nl.ndarray(x.shape, dtype=x.dtype, buffer=nl.shared_hbm).
Load the whole input into SBUF with nisa.dma_copy(dst=in_tile, src=x).
Use nl.affine_range(F1) and nl.affine_range(F2) for index loops.
To copy a COLUMN while retaining the 2-D (P,1) tile shape, use:
nisa.tensor_copy(dst=out_tile[:,nl.ds(j*F1+i,1)], src=in_tile[:,nl.ds(i*F2+j,1)])
Then nisa.dma_copy(dst=out, src=out_tile); return out.
nl.ds(start,size) above makes a contiguous slice of size 1, not a scalar index.
dma_copy requires matching element counts; tensor_copy here stays SBUF-to-SBUF.
Derive all sizes from x.shape/shape2D; do not pad to unrelated fixed tile sizes.
The supplied test partitions P are <=128. No channel/partition transpose is needed.
No sums, scaling, or matmul are needed. Do not use NumPy/PyTorch transpose shortcuts.
"""

def available_names_2(dotted):
    return (f' `{dotted}` does not exist. Do not guess similar names. '
            'Use the transpose-specific nisa.tensor_copy/nl.ds pattern in the API card.')

def real_signature_2(func_name):
    """The actual signature of an NKI function, for when the model invents arguments."""
    import inspect
    for mod_name in ("nki.language", "nki.isa", "nki"):
        try:
            mod = __import__(mod_name, fromlist=["x"])
        except Exception:
            continue
        fn = getattr(mod, func_name, None)
        if fn is None:
            continue
        try:
            return f"{mod_name.split('.')[-1]}.{func_name}{inspect.signature(fn)}"
        except (TypeError, ValueError):
            return f"{mod_name.split('.')[-1]}.{func_name}"
    return ""

def enrich_2(error_text, source='', error=None):
    location = ''
    tb = getattr(error, '__traceback__', None)
    while tb:
        if '_agent_level' in tb.tb_frame.f_code.co_filename:
            lines = source.splitlines()
            line = lines[tb.tb_lineno - 1] if tb.tb_lineno <= len(lines) else ''
            location = f' Candidate line {tb.tb_lineno}: {line.strip()[:180]}. '
        tb = tb.tb_next
    prefix = error_text + location
    if 'same number of elements' in error_text:
        return prefix + (' Match the actual source and destination slices. Whole-tensor DMA uses '
                         '(P,F1*F2) on both sides; one-column SBUF copies use (P,1) on both sides. '
                         'Do not allocate 128x128 or other fixed-size tiles. Fix allocation/copy sizes first.')
    if 'partition dimension' in error_text and 'exceeds' in error_text:
        return prefix + (' P is the partition axis; keep it unchanged. All provided P values are <=128. '
                         'Do not move F1*F2 into the partition axis. Use tiles shaped (P,F1*F2).')
    if 'must have at least 2 dimensions' in error_text:
        return prefix + ' Keep column slices 2-D: tile[:,nl.ds(index,1)] has shape (P,1); avoid scalar indexing.'
    if 'cannot reshape array of size' in error_text:
        return prefix + ' Keep input/output tiles shaped x.shape; reorder flattened columns using src=i*F2+j and dst=j*F1+i.'
    if "'MemoryRegion' object is not callable" in error_text:
        return prefix + ' Allocate with nl.ndarray(x.shape, dtype=x.dtype, buffer=nl.sbuf); do not call nl.sbuf.'
    match = re.search(r"(\w+)\(\) got an unexpected keyword argument '(\w+)'", error_text)
    if match:
        signature = real_signature_2(match.group(1))
        return prefix + f' Remove unsupported argument `{match.group(2)}`.' + (f' Installed signature: {signature}.' if signature else '')
    if 'shared_hbm' in error_text and 'must be in' in error_text:
        return prefix + ' Use tensor_copy between SBUF tiles; use dma_copy to load/store HBM. Do not tensor_copy directly into the HBM output.'
    if 'has no attribute' in error_text:
        return prefix + ' Use nisa.tensor_copy with nl.ds(start,1) between SBUF column slices. Transpose requires no reductions or arithmetic.'
    return prefix + ' Check the transpose API card, slice shapes, and src=i*F2+j / dst=j*F1+i mapping.'

def first_prompt_2(level, terse=0):
    if level != 2:
        raise ValueError('This version enables level 2 only.')
    entry = nkibench.LEVELS[2]['entry']
    return (
        f'Write a complete NKI function {entry}(x, shape2D), decorated with @nki.jit.\n'
        'Transpose each flattened F1-by-F2 matrix within its partition row; output shape stays x.shape.\n'
        'Example: a row [0,1,2,3,4,5] with shape2D=(2,3) becomes [0,3,1,4,2,5].\n'
        'Tests: (P,F,shape2D)=(32,12,(3,4)), (128,64,(8,8)), (64,128,(4,32)), (8,35,(5,7)).\n'
        'Use this order: allocate/load SBUF, reorder columns into new SBUF, store/return new HBM output.\n'
        + API_CARD_2 + '\nReturn one complete concise Python code block, no prose.'
    )

def repair_prompt_2(level, source, feedback):
    if level != 2:
        raise ValueError('This version enables level 2 only.')
    if len(source) > 10000:
        return first_prompt_2(2) + '\nRewrite concisely; previous failure:\n' + feedback[:1800]
    return (
        f'Repair the NKI transpose kernel `{nkibench.LEVELS[2]["entry"]}`.\n'
        + API_CARD_2 + '\nPrevious candidate:\n```python\n' + source + '\n```\n'
        + 'Checker feedback:\n' + feedback[:1800] + '\n'
        'Fix the named failure first; related allocations and loops may change. '
        'Keep P unchanged and preserve input values exactly. '
        'Return one complete concise Python code block, no prose.'
    )

CODE_BLOCK_2 = re.compile(r"```(?:python)?\s*(.*?)```", re.S)

def extract_code_2(text):
    """Pull out the code, and return NOTHING rather than prose.
    The old fallback returned the whole reply whenever it contained "def ", so a numbered list
    or a sentence reached the compiler and produced "invalid decimal literal on line 2" -- a
    parse error that blamed the model for the extractor's mistake.
    """
    text = text or ""
    blocks = CODE_BLOCK_2.findall(text)
    if blocks:
        return max(blocks, key=len).strip()
    # No fence: start at the first line that can legally begin a module and keep the rest.
    lines = text.splitlines()
    for i, line in enumerate(lines):
        if re.match(r"^\s*(import |from |@nki|def )", line):
            return "\n".join(lines[i:]).strip()
    return ""

def ask_2(a, prompt):
    import httpx
    # enable_thinking=False matters. Qwen3 reasons before answering, and with thinking on it
    # spent the whole budget there: the first cluster run returned "No code came back" at 54.7s
    # over and over, plus truncated fragments (invalid decimal literal, unterminated string).
    # Keep prompt + answer inside the server's context, or the answer is silently cut off and
    # every parse error below is really a budget error. Repair prompts grow with the kernel.
    # Conservative character estimate; still not an exact tokenizer count.
    est_prompt = (len(prompt) + 2) // 3
    remaining = a.context - est_prompt - 256
    if remaining < 256:
        raise SystemExit("Prompt exceeds the safe context budget; shorten the candidate/feedback.")
    budget = min(a.max_tokens, remaining)
    if budget < a.max_tokens:
        print(f"    (prompt is ~{est_prompt} tokens, so the answer budget is capped at {budget} "
              f"to stay inside the {a.context}-token context)")
    body = dict(model=a.model, messages=[{"role": "user", "content": prompt}],
                max_tokens=budget, temperature=0.6, top_p=0.95,
                chat_template_kwargs={"enable_thinking": a.think})
    r = httpx.post(f"{a.base.rstrip('/')}/chat/completions", json=body,
                   timeout=900, verify=False)
    if r.status_code != 200:
        raise SystemExit(f"the endpoint returned HTTP {r.status_code}:\n{r.text[:600]}")
    payload = r.json()
    ch = payload["choices"][0]
    msg = ch.get("message", {})
    reasoning = next((msg[k] for k in REASONING_KEYS_2 if msg.get(k)), "")
    content = msg.get("content") or ""
    finish = ch.get("finish_reason")
    if finish == "length":
        # Do not let a budget problem look like a model failure.
        print(f"    (TRUNCATED: finish_reason=length after {len(content)} chars. The answer was "
              f"cut off, so any parse error below is the budget, not the model. Prompt is "
              f"{len(prompt)} chars; server context is the ceiling.)")
    if not content.strip() and reasoning:
        # The single most common surprise on this endpoint, so name it rather than reporting
        # an empty answer as a model failure.
        print(f"    (empty answer, {len(reasoning)} chars of hidden reasoning, "
              f"finish={ch.get('finish_reason')} — shorten the prompt rather than raising the "
              f"budget)")
    return content

def ask_parallel_2(a, prompt, n):
    import concurrent.futures as cf
    with cf.ThreadPoolExecutor(max_workers=n) as ex:
        return [f.result() for f in [ex.submit(ask_2, a, prompt) for _ in range(n)]]

def offline_answers_2(level, n, rnd):
    """No model. Replays the shipped reference, preceded by a deliberately broken version, so the
    loop and the feedback path can be exercised with no endpoint. Never report a number."""
    ref = open(f"reference_level{level}.py").read()
    if rnd == 0:
        broken = ref.replace("@nki.jit", "", 1)
        return [f"```python\n{broken}\n```"] * n
    return [f"```python\n{ref}\n```"] * n

def solve_2(a, level, log):
    print(f"\n=========== level {level}: {nkibench.LEVELS[level]['op']} ===========")
    terse = a.terse
    prompt = first_prompt_2(level, terse)
    best = (0.0, None, "")
    tried, streak, seen = [], 0, {}
    latest = ("", "")
    for rnd in range(a.rounds):
        t0 = time.perf_counter()
        replies = (offline_answers_2(level, a.samples, rnd) if a.offline
                   else ask_parallel_2(a, prompt, a.samples))
        graded = []
        for reply in replies:
            src = extract_code_2(reply)
            reward, parts, feedback = grade_2(src, level)
            graded.append((reward, src, feedback, parts))
            log.write(json.dumps(dict(level=level, round=rnd, reward=reward, parts=parts,
                                      prompt_chars=len(prompt), reply_chars=len(reply),
                                      code=src, feedback=feedback)) + "\n")
        log.flush()
        graded.sort(key=lambda g: g[0], reverse=True)
        top = graded[0]
        if top[0] > best[0]:
            best = (top[0], top[1], top[2])
        # Repair the LATEST attempt, not the best one. Rebuilding from the best attempt with the
        # best attempt's feedback is a fixed point: once a round scores worse, the prompt stops
        # changing, and a greedy model then returns the same answer forever. Measured: level 2
        # stuck at 0.10 for four rounds while the prompt still carried the 0.50 code.
        if (top[1] or "").strip():
            latest = (top[1], top[2])
        same = top[2] == (tried[-1] if tried else None)
        if same:
            # Collapse. Fifteen identical multi-line blocks is noise, not information.
            print(f"round {rnd}: same failure again ({top[0]:.2f}, best so far {best[0]:.2f})")
        else:
            print(f"round {rnd}: this round {top[0]:.2f}  best so far {best[0]:.2f}  "
                  f"({time.perf_counter() - t0:.1f}s)")
            print(f"  {top[2][:400]}")
        if top[0] >= sum(WEIGHTS_2.values()) - 1e-9:
            print(f"  SOLVED on round {rnd}. {top[2]}")
            print("  ---------------- the kernel ----------------")
            print(textwrap.indent(top[1], "  "))
            print("  -------------------------------------------")
            if not a.offline:
                with open("solution_level2.py", "w") as saved:
                    saved.write(top[1])
                print("  saved successful candidate to solution_level2.py")
            return top[0], rnd + 1
        seen[top[2]] = seen.get(top[2], 0) + 1
        streak = streak + 1 if same else 1
        if seen[top[2]] >= a.give_up_after:
            how = ("the identical failure %d rounds running" % streak if streak >= a.give_up_after
                   else "this failure for the %dth time, alternating with %d other(s)"
                        % (seen[top[2]], len(seen) - 1))
            print(f"  STOPPING this level: {how}. The agent is cycling between a fixed set of "
                  f"mistakes rather than converging, so more rounds will not help. Failures seen:")
            for f, n in sorted(seen.items(), key=lambda kv: -kv[1]):
                print(f"    {n}x  {f[:110]}")
            return best[0], rnd + 1
        tried.append(top[2])
        repeats = streak
        if repeats >= 2 and (best[1] or "").strip():
            # Sampling on this endpoint is greedy, so an unchanged prompt returns an unchanged
            # answer. Measured: the same TypeError 19 rounds running. Changing the prompt is the
            # only thing that can change the answer, so say what has already been tried.
            ledger = "\n".join(f"- {t[:160]}" for t in list(dict.fromkeys(tried))[-2:])
            prompt = (repair_prompt_2(level, latest[0], latest[1])
                      + f"\n\nThese approaches have already failed, so do something different:\n"
                        f"{ledger}")
            print(f"  same failure {repeats}x — adding a ledger of {len(set(tried))} failed "
                  f"attempts to break the repeat")
            continue
        if not (latest[0] or "").strip():
            # Nothing came back to repair. Asking it to "fix" an empty code block produced a
            # 202-character prompt and, under greedy sampling, the identical non-answer six
            # rounds running. Shorten and re-ask instead.
            terse = min(terse + 1, 2)
            prompt = first_prompt_2(level, terse)
            print(f"  no code yet, so re-asking with a shorter prompt (terseness {terse})")
        else:
            prompt = repair_prompt_2(level, latest[0], latest[1])
    print(f"  not solved in {a.rounds} rounds; best reward {best[0]:.2f}")
    return best[0], a.rounds


# Level 3: preserved from agent.level3.20261010-140513.py
MODEL_3 = os.environ.get("KERNEL_AGENT_MODEL", "Qwen/Qwen3-8B")

MIN_ANSWER_TOKENS_3 = 2500

REASONING_KEYS_3 = ("reasoning", "reasoning_content")

WEIGHTS_3 = dict(parses=0.1, rules=0.2, runs=0.2, correct=0.5)

def matmul_api_violations_3(source):
    """Recognize aliased framework shortcuts and unsafe direct HBM assignments."""
    tree = ast.parse(source)
    aliases, hbm_outputs = {}, set()
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            for alias in node.names:
                aliases[alias.asname or alias.name.split('.')[0]] = (
                    alias.name if alias.asname else alias.name.split('.')[0])
        elif isinstance(node, ast.ImportFrom) and node.module:
            for alias in node.names:
                aliases[alias.asname or alias.name] = node.module + '.' + alias.name
    def resolve(node):
        dotted = ast.unparse(node)
        head, dot, tail = dotted.partition('.')
        return aliases.get(head, head) + (dot + tail if dot else '')
    for node in ast.walk(tree):
        if isinstance(node, ast.Assign) and isinstance(node.value, ast.Call):
            if resolve(node.value.func) == 'nki.language.ndarray' and any(
                kw.arg == 'buffer' and resolve(kw.value) == 'nki.language.shared_hbm'
                for kw in node.value.keywords
            ):
                hbm_outputs.update(t.id for t in node.targets if isinstance(t, ast.Name))
    bad = []
    for node in ast.walk(tree):
        if isinstance(node, ast.Call):
            resolved = resolve(node.func)
            if (resolved.split('.')[0] in {'numpy', 'torch', 'jax', 'np', 'jnp', 'F', 'nn'}
                and resolved.split('.')[-1] in nkibench.LEVELS[3]['banned']):
                bad.append(f'line {node.lineno}: framework shortcut `{ast.unparse(node.func)}` is prohibited. '
                           'Use nisa.nc_matmul with SBUF inputs and a float32 PSUM destination.')
            if resolved in {'nki.isa.add', 'nki.isa.reduce_sum', 'nki.isa.multiply', 'nki.isa.scalar_mul'}:
                bad.append(f'line {node.lineno}: `{ast.unparse(node.func)}` is not needed or supported here. '
                           'Use nisa.nc_matmul for the matrix product; no manual scalar accumulation is needed.')
        targets = []
        if isinstance(node, ast.Assign):
            targets = node.targets
        elif isinstance(node, (ast.AugAssign, ast.AnnAssign)):
            targets = [node.target]
        for target in targets:
            root = target
            while isinstance(root, ast.Subscript):
                root = root.value
            if isinstance(target, ast.Subscript) and isinstance(root, ast.Name) and root.id in hbm_outputs:
                bad.append(f'line {node.lineno}: direct assignment into HBM output `{root.id}`. '
                           'Compute into PSUM, tensor_copy to SBUF, then dma_copy to HBM.')
    return bad

def grade_3(source, level):
    """Returns (reward, parts, feedback). Feedback is an INSTRUCTION, never just a verdict."""
    if level != 3:
        raise ValueError("Only level 3 is enabled.")
    parts = dict(parses=False, rules=False, runs=False, correct=False)
    if not source.strip():
        return 0.0, parts, ("No code came back. Reply with one python code block containing the "
                            "kernel and nothing else.")
    try:
        compile(source, "<candidate>", "exec")
        parts["parses"] = True
    except SyntaxError as e:
        return (WEIGHTS_3["parses"] * 0, parts,
                f"The code does not parse: {e.msg} on line {e.lineno}. Send one complete python "
                f"code block.")
    violations = matmul_api_violations_3(source) + nkibench.check_rules(source, level)
    if violations:
        extra = ""
        if any("no function named" in v for v in violations):
            # Measured: this repeated 15 rounds running, because "there is no function named X"
            # never said what the function should look like. Hand over the exact line.
            import inspect
            ref = nkibench.LEVELS[level]["ref"]
            args = ", ".join(inspect.signature(ref).parameters)
            extra = (f" Start the function with exactly this line:  "
                     f"def {nkibench.LEVELS[level]['entry']}({args}):  "
                     f"and put @nki.jit on the line above it.")
        return (sum(WEIGHTS_3[k] for k, v in parts.items() if v), parts,
                "Rule violations, which score zero however fast the kernel is. Fix exactly "
                "these: " + " ".join(violations) + extra)
    parts["rules"] = True
    spec = nkibench.LEVELS[level]
    path = f"/tmp/_agent_level{level}.py"
    with open(path, "w") as f:
        f.write(source)
    try:
        kernel = nkibench.load_kernel(path, spec["entry"])
    except ModuleNotFoundError as e:
        # Two very different causes, and conflating them aborted a whole run: either the SDK is
        # absent (an environment problem the model cannot fix), or the model imported a module it
        # invented -- observed: `import nki.nl`. Tell them apart by asking whether nki itself is
        # importable.
        try:
            import nki  # noqa: F401
            sdk_present = True
        except ImportError:
            sdk_present = False
        if not sdk_present:
            raise SystemExit(
                f"cannot import {e.name!r}, so no NKI kernel can be loaded here. Run this where "
                f"the Neuron SDK exists -- k8s/kernel-agent-job.yaml does that -- or use "
                f"--offline to exercise the loop without a kernel ever running.") from e
        return (sum(WEIGHTS_3[k] for k, v in parts.items() if v), parts,
                f"There is no module named {e.name!r}. The only imports that exist are: "
                f"`import nki`, `import nki.language as nl`, and `import nki.isa as nisa`. "
                f"Use exactly those three.")
    except Exception as e:
        return (sum(WEIGHTS_3[k] for k, v in parts.items() if v), parts,
                f"The file imports but {spec['entry']} could not be loaded: "
                + enrich_3(f"{type(e).__name__}: {e}", source, e))
    failures, passed, intensity = [], 0, None
    dma_metrics = []
    for case in spec["shapes"]:
        args, _ = nkibench.make_inputs(case, level)
        before = [x.copy() if isinstance(x, np.ndarray) else x for x in args]
        want = spec["ref"](*args)
        try:
            got, counted = nkibench.simulate_and_count(kernel, args)
        except nkibench.NkiMissing as e:
            return (sum(WEIGHTS_3[k] for k, v in parts.items() if v), parts,
                    f"CANNOT SIMULATE: {e}")
        except Exception as e:
            failures.append((nkibench.label(case, level),
                             enrich_3(f"raised {type(e).__name__}: {e}", source, e)))
            continue
        parts["runs"] = True
        m = (nkibench.check_inputs_untouched(before, args)
             or nkibench.describe_mismatch(got, want)
             or nkibench.check_traffic_bar(level, counted, args, want))
        # A simulator warning about a hardware-correctness hazard counts as a failure even when the
        # numbers happen to match on CPU: the kernel would be wrong on the device.
        hazards = [w for w in counted.get("warnings", [])
                   if "incorrect results on hardware" in w]
        if hazards and not m:
            m = ("CORRECT ON CPU BUT WRONG ON HARDWARE: " + hazards[0]
                 + ". Fix that before anything else -- the simulator agrees with the reference here "
                   "and the device would not.")
        if m:
            failures.append((nkibench.label(case, level), m))
            continue
        passed += 1
        dma_metrics.append(f"{nkibench.label(case, level)}: "
                           f"{counted.get('bytes', 0)} DMA bytes, "
                           f"{counted.get('transfers', 0)} DMA calls"
                           + (" (byte count incomplete)" if counted.get("unmeasured") else ""))
        # Level 3 focuses on correctness; real device timing is not measured here.
    if failures:
        lbl, first = failures[0]
        return (sum(WEIGHTS_3[k] for k, v in parts.items() if v)
                + WEIGHTS_3["correct"] * passed / len(spec["shapes"]), parts,
                f"{passed} of {len(spec['shapes'])} shapes passed. On {lbl}: {first}")

    parts["correct"] = True
    reward = sum(WEIGHTS_3.values())
    note = "Correct on the level-3 single-tile test, within the checker numerical tolerance."
    if dma_metrics:
        note += " Simulator DMA metrics (not device timings or SBUF copy counts): " + "; ".join(dma_metrics)
    if intensity:
        note += " " + nkibench.explain_roofline(intensity)
    return reward, parts, note

API_CARD_3 = """Single-tile matmul NKI usage, based on reference_level3.py:
import nki; import nki.language as nl; import nki.isa as nisa
lhsT has shape (K,M), rhs has shape (K,N), output has shape (M,N).
The mathematical result is lhsT.T @ rhs, but DO NOT transpose lhsT in kernel code.
nc_matmul expects both operands with K as their first (partition) axis, so lhsT is already in the correct layout.
For level 3 only: K=128, M=64, N=512. This fits ONE tile; no tiling loops or reshape are necessary.
Load inputs into SBUF:
lhs_tile=nl.ndarray(lhsT.shape,dtype=lhsT.dtype,buffer=nl.sbuf)
rhs_tile=nl.ndarray(rhs.shape,dtype=rhs.dtype,buffer=nl.sbuf)
nisa.dma_copy(dst=lhs_tile,src=lhsT); nisa.dma_copy(dst=rhs_tile,src=rhs)
Allocate a 2-D float32 PSUM result:
acc=nl.ndarray((M,N),dtype=nl.float32,buffer=nl.psum)
nisa.nc_matmul(dst=acc,stationary=lhs_tile,moving=rhs_tile)
Convert/copy PSUM to SBUF with nisa.tensor_copy(dst=result_sbuf,src=acc).
result_sbuf must have shape (M,N), dtype=lhsT.dtype, buffer=nl.sbuf.
Finally allocate a NEW (M,N) output in nl.shared_hbm; dma_copy the SBUF result into it and return it.
Never send HBM operands directly into nc_matmul; never tensor_copy PSUM directly into HBM.
All buffers remain two-dimensional. dma_copy must preserve element counts.
Do not use numpy/torch matmul, dot, einsum, the Python @ operator, or host transpose.
Use keyword arguments for nc_matmul; do not invent transpose_moving or transpose_stationary flags.
"""

def available_names_3(dotted):
    return (f' `{dotted}` does not exist. Do not guess similar names. '
            'Use the single-tile nc_matmul / tensor_copy / dma_copy pattern in the API card.')

def real_signature_3(func_name):
    """The actual signature of an NKI function, for when the model invents arguments."""
    import inspect
    for mod_name in ("nki.language", "nki.isa", "nki"):
        try:
            mod = __import__(mod_name, fromlist=["x"])
        except Exception:
            continue
        fn = getattr(mod, func_name, None)
        if fn is None:
            continue
        try:
            return f"{mod_name.split('.')[-1]}.{func_name}{inspect.signature(fn)}"
        except (TypeError, ValueError):
            return f"{mod_name.split('.')[-1]}.{func_name}"
    return ""

def enrich_3(error_text, source='', error=None):
    location = ''
    tb = getattr(error, '__traceback__', None)
    while tb:
        if '_agent_level' in tb.tb_frame.f_code.co_filename:
            lines = source.splitlines()
            line = lines[tb.tb_lineno-1] if tb.tb_lineno <= len(lines) else ''
            location = f' Candidate line {tb.tb_lineno}: {line.strip()[:180]}. '
        tb = tb.tb_next
    prefix = error_text + location
    if 'must have at least 2 dimensions' in error_text:
        return prefix + ' Allocate 2-D tiles: lhs=(128,64), rhs=(128,512), result=(64,512). Do not create scalar/1-D SBUF or PSUM buffers.'
    if 'cannot reshape array of size' in error_text:
        return prefix + ' No reshape is needed. Keep lhsT.shape=(128,64), rhs.shape=(128,512), and result shape=(64,512).'
    if 'same number of elements' in error_text:
        return prefix + ' Match input SBUF buffers to each input shape. Match PSUM, result SBUF and output to (M,N). Do not copy an input into a result-sized buffer.'
    if 'partition dimension' in error_text and 'exceeds' in error_text:
        return prefix + ' Keep input K=128 on the first axis. Do not transpose rhs to (512,128). The output first axis is M=64.'
    if "'MemoryRegion' object is not callable" in error_text:
        return prefix + ' Use nl.ndarray(shape,dtype=...,buffer=nl.sbuf or nl.psum); memory regions are not functions.'
    if 'shared_hbm' in error_text and 'must be in' in error_text:
        return prefix + ' nc_matmul consumes SBUF and writes PSUM. tensor_copy moves PSUM->SBUF; dma_copy moves SBUF->HBM.'
    if 'must be in' in error_text:
        return prefix + ' For nc_matmul: dst uses nl.psum and dtype nl.float32; stationary and moving both use nl.sbuf.'
    match = re.search(r"(\w+)\(\) got an unexpected keyword argument '(\w+)'", error_text)
    if match:
        signature = real_signature_3(match.group(1))
        return prefix + f' Remove unsupported `{match.group(2)}=`.' + (f' Installed signature: {signature}.' if signature else '') + ' lhsT already has the layout required by nc_matmul; no transpose flag is needed.'
    if 'has no attribute' in error_text or 'unsupported operand type' in error_text:
        return prefix + ' Use nisa.nc_matmul(dst=acc,stationary=lhs_tile,moving=rhs_tile). Do not replace matmul with guessed APIs or Python arithmetic on NKI tensors.'
    return prefix + ' Check the two input layouts, PSUM destination, then PSUM->SBUF->HBM copy sequence.'

def first_prompt_3(level, terse=0):
    if level != 3:
        raise ValueError('This version enables level 3 only.')
    entry = nkibench.LEVELS[3]['entry']
    return (
        f'Write a complete NKI function {entry}(lhsT,rhs), decorated with @nki.jit.\n'
        'Implement level 3: single-tile matrix multiplication, inputs float32 (128,64) and (128,512), output (64,512).\n'
        'Do not modify inputs. Focus on correctness; do not add loops, reshapes or unrelated operations.\n'
        + API_CARD_3 + '\nReturn one complete concise Python code block, no prose.'
    )

def repair_prompt_3(level, source, feedback):
    if level != 3:
        raise ValueError('This version enables level 3 only.')
    if len(source) > 10000:
        return first_prompt_3(3) + '\nRewrite concisely; previous failure:\n' + feedback[:1800]
    return (
        f'Repair the single-tile NKI matmul kernel `{nkibench.LEVELS[3]["entry"]}`.\n'
        + API_CARD_3 + '\nPrevious candidate:\n```python\n' + source + '\n```\n'
        + 'Checker feedback:\n' + feedback[:1800] + '\n'
        'Fix the reported issue first; related buffer changes are allowed. '
        'Keep lhsT=(K,M), rhs=(K,N), output=(M,N). '
        'Return one complete concise Python code block, no prose.'
    )

CODE_BLOCK_3 = re.compile(r"```(?:python)?\s*(.*?)```", re.S)

def extract_code_3(text):
    """Pull out the code, and return NOTHING rather than prose.
    The old fallback returned the whole reply whenever it contained "def ", so a numbered list
    or a sentence reached the compiler and produced "invalid decimal literal on line 2" -- a
    parse error that blamed the model for the extractor's mistake.
    """
    text = text or ""
    blocks = CODE_BLOCK_3.findall(text)
    if blocks:
        return max(blocks, key=len).strip()
    # No fence: start at the first line that can legally begin a module and keep the rest.
    lines = text.splitlines()
    for i, line in enumerate(lines):
        if re.match(r"^\s*(import |from |@nki|def )", line):
            return "\n".join(lines[i:]).strip()
    return ""

def ask_3(a, prompt):
    import httpx
    # enable_thinking=False matters. Qwen3 reasons before answering, and with thinking on it
    # spent the whole budget there: the first cluster run returned "No code came back" at 54.7s
    # over and over, plus truncated fragments (invalid decimal literal, unterminated string).
    # Keep prompt + answer inside the server's context, or the answer is silently cut off and
    # every parse error below is really a budget error. Repair prompts grow with the kernel.
    # Conservative character estimate; still not an exact tokenizer count.
    est_prompt = (len(prompt) + 2) // 3
    remaining = a.context - est_prompt - 256
    if remaining < 256:
        raise SystemExit("Prompt exceeds the safe context budget; shorten the candidate/feedback.")
    budget = min(a.max_tokens, remaining)
    if budget < a.max_tokens:
        print(f"    (prompt is ~{est_prompt} tokens, so the answer budget is capped at {budget} "
              f"to stay inside the {a.context}-token context)")
    body = dict(model=a.model, messages=[{"role": "user", "content": prompt}],
                max_tokens=budget, temperature=0.6, top_p=0.95,
                chat_template_kwargs={"enable_thinking": a.think})
    r = httpx.post(f"{a.base.rstrip('/')}/chat/completions", json=body,
                   timeout=900, verify=False)
    if r.status_code != 200:
        raise SystemExit(f"the endpoint returned HTTP {r.status_code}:\n{r.text[:600]}")
    payload = r.json()
    ch = payload["choices"][0]
    msg = ch.get("message", {})
    reasoning = next((msg[k] for k in REASONING_KEYS_3 if msg.get(k)), "")
    content = msg.get("content") or ""
    finish = ch.get("finish_reason")
    if finish == "length":
        # Do not let a budget problem look like a model failure.
        print(f"    (TRUNCATED: finish_reason=length after {len(content)} chars. The answer was "
              f"cut off, so any parse error below is the budget, not the model. Prompt is "
              f"{len(prompt)} chars; server context is the ceiling.)")
    if not content.strip() and reasoning:
        # The single most common surprise on this endpoint, so name it rather than reporting
        # an empty answer as a model failure.
        print(f"    (empty answer, {len(reasoning)} chars of hidden reasoning, "
              f"finish={ch.get('finish_reason')} — shorten the prompt rather than raising the "
              f"budget)")
    return content

def ask_parallel_3(a, prompt, n):
    import concurrent.futures as cf
    with cf.ThreadPoolExecutor(max_workers=n) as ex:
        return [f.result() for f in [ex.submit(ask_3, a, prompt) for _ in range(n)]]

def offline_answers_3(level, n, rnd):
    """No model. Replays the shipped reference, preceded by a deliberately broken version, so the
    loop and the feedback path can be exercised with no endpoint. Never report a number."""
    ref = open(f"reference_level{level}.py").read()
    if rnd == 0:
        broken = ref.replace("@nki.jit", "", 1)
        return [f"```python\n{broken}\n```"] * n
    return [f"```python\n{ref}\n```"] * n

def solve_3(a, level, log):
    print(f"\n=========== level {level}: {nkibench.LEVELS[level]['op']} ===========")
    terse = a.terse
    prompt = first_prompt_3(level, terse)
    best = (0.0, None, "")
    tried, streak, seen = [], 0, {}
    latest = ("", "")
    for rnd in range(a.rounds):
        t0 = time.perf_counter()
        replies = (offline_answers_3(level, a.samples, rnd) if a.offline
                   else ask_parallel_3(a, prompt, a.samples))
        graded = []
        for reply in replies:
            src = extract_code_3(reply)
            reward, parts, feedback = grade_3(src, level)
            graded.append((reward, src, feedback, parts))
            log.write(json.dumps(dict(level=level, round=rnd, reward=reward, parts=parts,
                                      prompt_chars=len(prompt), reply_chars=len(reply),
                                      code=src, feedback=feedback)) + "\n")
        log.flush()
        graded.sort(key=lambda g: g[0], reverse=True)
        top = graded[0]
        if top[0] > best[0]:
            best = (top[0], top[1], top[2])
        # Repair the LATEST attempt, not the best one. Rebuilding from the best attempt with the
        # best attempt's feedback is a fixed point: once a round scores worse, the prompt stops
        # changing, and a greedy model then returns the same answer forever. Measured: level 2
        # stuck at 0.10 for four rounds while the prompt still carried the 0.50 code.
        if (top[1] or "").strip():
            latest = (top[1], top[2])
        same = top[2] == (tried[-1] if tried else None)
        if same:
            # Collapse. Fifteen identical multi-line blocks is noise, not information.
            print(f"round {rnd}: same failure again ({top[0]:.2f}, best so far {best[0]:.2f})")
        else:
            print(f"round {rnd}: this round {top[0]:.2f}  best so far {best[0]:.2f}  "
                  f"({time.perf_counter() - t0:.1f}s)")
            print(f"  {top[2][:400]}")
        if top[0] >= sum(WEIGHTS_3.values()) - 1e-9:
            print(f"  SOLVED on round {rnd}. {top[2]}")
            print("  ---------------- the kernel ----------------")
            print(textwrap.indent(top[1], "  "))
            print("  -------------------------------------------")
            if not a.offline:
                with open("solution_level3.py", "w") as saved:
                    saved.write(top[1])
                print("  saved successful candidate to solution_level3.py")
            return top[0], rnd + 1
        seen[top[2]] = seen.get(top[2], 0) + 1
        streak = streak + 1 if same else 1
        if seen[top[2]] >= a.give_up_after:
            how = ("the identical failure %d rounds running" % streak if streak >= a.give_up_after
                   else "this failure for the %dth time, alternating with %d other(s)"
                        % (seen[top[2]], len(seen) - 1))
            print(f"  STOPPING this level: {how}. The agent is cycling between a fixed set of "
                  f"mistakes rather than converging, so more rounds will not help. Failures seen:")
            for f, n in sorted(seen.items(), key=lambda kv: -kv[1]):
                print(f"    {n}x  {f[:110]}")
            return best[0], rnd + 1
        tried.append(top[2])
        repeats = streak
        if repeats >= 2 and (best[1] or "").strip():
            # Sampling on this endpoint is greedy, so an unchanged prompt returns an unchanged
            # answer. Measured: the same TypeError 19 rounds running. Changing the prompt is the
            # only thing that can change the answer, so say what has already been tried.
            ledger = "\n".join(f"- {t[:160]}" for t in list(dict.fromkeys(tried))[-2:])
            prompt = (repair_prompt_3(level, latest[0], latest[1])
                      + f"\n\nThese approaches have already failed, so do something different:\n"
                        f"{ledger}")
            print(f"  same failure {repeats}x — adding a ledger of {len(set(tried))} failed "
                  f"attempts to break the repeat")
            continue
        if not (latest[0] or "").strip():
            # Nothing came back to repair. Asking it to "fix" an empty code block produced a
            # 202-character prompt and, under greedy sampling, the identical non-answer six
            # rounds running. Shorten and re-ask instead.
            terse = min(terse + 1, 2)
            prompt = first_prompt_3(level, terse)
            print(f"  no code yet, so re-asking with a shorter prompt (terseness {terse})")
        else:
            prompt = repair_prompt_3(level, latest[0], latest[1])
    print(f"  not solved in {a.rounds} rounds; best reward {best[0]:.2f}")
    return best[0], a.rounds


# Level 4: preserved from agent.level4.20261010-141517.py
MODEL_4 = os.environ.get("KERNEL_AGENT_MODEL", "Qwen/Qwen3-8B")

MIN_ANSWER_TOKENS_4 = 2500

REASONING_KEYS_4 = ("reasoning", "reasoning_content")

WEIGHTS_4 = dict(parses=0.1, rules=0.2, runs=0.2, correct=0.5)

def matmul_api_violations_4(source):
    """Recognize aliased framework shortcuts and unsafe direct HBM assignments."""
    tree = ast.parse(source)
    aliases, hbm_outputs = {}, set()
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            for alias in node.names:
                aliases[alias.asname or alias.name.split('.')[0]] = (
                    alias.name if alias.asname else alias.name.split('.')[0])
        elif isinstance(node, ast.ImportFrom) and node.module:
            for alias in node.names:
                aliases[alias.asname or alias.name] = node.module + '.' + alias.name
    def resolve(node):
        dotted = ast.unparse(node)
        head, dot, tail = dotted.partition('.')
        return aliases.get(head, head) + (dot + tail if dot else '')
    for node in ast.walk(tree):
        if isinstance(node, ast.Assign) and isinstance(node.value, ast.Call):
            if resolve(node.value.func) == 'nki.language.ndarray' and any(
                kw.arg == 'buffer' and resolve(kw.value) == 'nki.language.shared_hbm'
                for kw in node.value.keywords
            ):
                hbm_outputs.update(t.id for t in node.targets if isinstance(t, ast.Name))
    bad = []
    for node in ast.walk(tree):
        if isinstance(node, ast.Call):
            resolved = resolve(node.func)
            if (resolved.split('.')[0] in {'numpy', 'torch', 'jax', 'np', 'jnp', 'F', 'nn'}
                and resolved.split('.')[-1] in nkibench.LEVELS[4]['banned']):
                bad.append(f'line {node.lineno}: framework shortcut `{ast.unparse(node.func)}` is prohibited. '
                           'Use nisa.nc_matmul with SBUF inputs and a float32 PSUM destination.')
            if resolved in {'nki.isa.add', 'nki.isa.reduce_sum', 'nki.isa.multiply', 'nki.isa.scalar_mul'}:
                bad.append(f'line {node.lineno}: `{ast.unparse(node.func)}` is not needed or supported here. '
                           'Use nisa.nc_matmul for the matrix product; accumulate K chunks in one PSUM tile, not Python scalar loops.')
        targets = []
        if isinstance(node, ast.Assign):
            targets = node.targets
        elif isinstance(node, (ast.AugAssign, ast.AnnAssign)):
            targets = [node.target]
        for target in targets:
            root = target
            while isinstance(root, ast.Subscript):
                root = root.value
            if isinstance(target, ast.Subscript) and isinstance(root, ast.Name) and root.id in hbm_outputs:
                bad.append(f'line {node.lineno}: direct assignment into HBM output `{root.id}`. '
                           'Compute into PSUM, tensor_copy to SBUF, then dma_copy to HBM.')
    return bad

def grade_4(source, level):
    """Returns (reward, parts, feedback). Feedback is an INSTRUCTION, never just a verdict."""
    if level != 4:
        raise ValueError("Only level 4 is enabled.")
    parts = dict(parses=False, rules=False, runs=False, correct=False)
    if not source.strip():
        return 0.0, parts, ("No code came back. Reply with one python code block containing the "
                            "kernel and nothing else.")
    try:
        compile(source, "<candidate>", "exec")
        parts["parses"] = True
    except SyntaxError as e:
        return (WEIGHTS_4["parses"] * 0, parts,
                f"The code does not parse: {e.msg} on line {e.lineno}. Send one complete python "
                f"code block.")
    violations = matmul_api_violations_4(source) + nkibench.check_rules(source, level)
    if violations:
        extra = ""
        if any("no function named" in v for v in violations):
            # Measured: this repeated 15 rounds running, because "there is no function named X"
            # never said what the function should look like. Hand over the exact line.
            import inspect
            ref = nkibench.LEVELS[level]["ref"]
            args = ", ".join(inspect.signature(ref).parameters)
            extra = (f" Start the function with exactly this line:  "
                     f"def {nkibench.LEVELS[level]['entry']}({args}):  "
                     f"and put @nki.jit on the line above it.")
        return (sum(WEIGHTS_4[k] for k, v in parts.items() if v), parts,
                "Rule violations, which score zero however fast the kernel is. Fix exactly "
                "these: " + " ".join(violations) + extra)
    parts["rules"] = True
    spec = nkibench.LEVELS[level]
    path = f"/tmp/_agent_level{level}.py"
    with open(path, "w") as f:
        f.write(source)
    try:
        kernel = nkibench.load_kernel(path, spec["entry"])
    except ModuleNotFoundError as e:
        # Two very different causes, and conflating them aborted a whole run: either the SDK is
        # absent (an environment problem the model cannot fix), or the model imported a module it
        # invented -- observed: `import nki.nl`. Tell them apart by asking whether nki itself is
        # importable.
        try:
            import nki  # noqa: F401
            sdk_present = True
        except ImportError:
            sdk_present = False
        if not sdk_present:
            raise SystemExit(
                f"cannot import {e.name!r}, so no NKI kernel can be loaded here. Run this where "
                f"the Neuron SDK exists -- k8s/kernel-agent-job.yaml does that -- or use "
                f"--offline to exercise the loop without a kernel ever running.") from e
        return (sum(WEIGHTS_4[k] for k, v in parts.items() if v), parts,
                f"There is no module named {e.name!r}. The only imports that exist are: "
                f"`import nki`, `import nki.language as nl`, and `import nki.isa as nisa`. "
                f"Use exactly those three.")
    except Exception as e:
        return (sum(WEIGHTS_4[k] for k, v in parts.items() if v), parts,
                f"The file imports but {spec['entry']} could not be loaded: "
                + enrich_4(f"{type(e).__name__}: {e}", source, e))
    failures, passed, intensity = [], 0, None
    dma_metrics = []
    for case in spec["shapes"]:
        args, _ = nkibench.make_inputs(case, level)
        before = [x.copy() if isinstance(x, np.ndarray) else x for x in args]
        want = spec["ref"](*args)
        try:
            got, counted = nkibench.simulate_and_count(kernel, args)
        except nkibench.NkiMissing as e:
            return (sum(WEIGHTS_4[k] for k, v in parts.items() if v), parts,
                    f"CANNOT SIMULATE: {e}")
        except Exception as e:
            failures.append((nkibench.label(case, level),
                             enrich_4(f"raised {type(e).__name__}: {e}", source, e)))
            continue
        parts["runs"] = True
        m = (nkibench.check_inputs_untouched(before, args)
             or nkibench.describe_mismatch(got, want)
             or nkibench.check_traffic_bar(level, counted, args, want))
        # A simulator warning about a hardware-correctness hazard counts as a failure even when the
        # numbers happen to match on CPU: the kernel would be wrong on the device.
        hazards = [w for w in counted.get("warnings", [])
                   if "incorrect results on hardware" in w]
        if hazards and not m:
            m = ("CORRECT ON CPU BUT WRONG ON HARDWARE: " + hazards[0]
                 + ". Fix that before anything else -- the simulator agrees with the reference here "
                   "and the device would not.")
        if m:
            failures.append((nkibench.label(case, level), m))
            continue
        passed += 1
        dma_metrics.append(f"{nkibench.label(case, level)}: "
                           f"{counted.get('bytes', 0)} DMA bytes, "
                           f"{counted.get('transfers', 0)} DMA calls"
                           + (" (byte count incomplete)" if counted.get("unmeasured") else ""))
        # Level 4 focuses on correctness; real device timing is not measured here.
    if failures:
        lbl, first = failures[0]
        return (sum(WEIGHTS_4[k] for k, v in parts.items() if v)
                + WEIGHTS_4["correct"] * passed / len(spec["shapes"]), parts,
                f"{passed} of {len(spec['shapes'])} shapes passed. On {lbl}: {first}")

    parts["correct"] = True
    reward = sum(WEIGHTS_4.values())
    note = "Correct on all level-4 tiled-matmul test shapes, within the checker numerical tolerance."
    if dma_metrics:
        note += " Simulator DMA metrics (not device timings or SBUF copy counts): " + "; ".join(dma_metrics)
    if intensity:
        note += " " + nkibench.explain_roofline(intensity)
    return reward, parts, note

API_CARD_4 = """Tiled-matmul NKI usage, based on reference_level4.py:
import nki; import nki.language as nl; import nki.isa as nisa
lhsT=(K,M), rhs=(K,N), output=(M,N). lhsT already has the layout nc_matmul expects; do not transpose it.
Level-4 tests (K,M,N): (128,128,512), (256,256,1024), (512,128,512), (256,512,1024).
Use tile sizes TK=128, TM=128, TN=512, matching nl.tile_size.pmax/gemm_stationary_fmax/gemm_moving_fmax.
All supplied dimensions are multiples of these tile sizes; this version targets those tests.
Allocate a NEW (M,N) output in nl.shared_hbm, dtype=lhsT.dtype.
Loop over m in nl.affine_range(M//TM), n in nl.affine_range(N//TN).
INSIDE each (m,n) output-tile loop, but OUTSIDE the k loop, allocate ONE:
acc=nl.ndarray((TM,TN),dtype=nl.float32,buffer=nl.psum)
Loop over k in nl.affine_range(K//TK).
Allocate lhs SBUF=(TK,TM), rhs SBUF=(TK,TN); never load a whole large input into one SBUF tile.
Load lhsT[k*TK:(k+1)*TK,m*TM:(m+1)*TM] into lhs_tile.
Load rhs[k*TK:(k+1)*TK,n*TN:(n+1)*TN] into rhs_tile.
nisa.dma_copy(dst=lhs_tile,src=...); nisa.dma_copy(dst=rhs_tile,src=...)
nisa.nc_matmul(dst=acc,stationary=lhs_tile,moving=rhs_tile)
Use the same acc across K iterations as in the reference; do not create/reset it inside the K loop or disable accumulation.
AFTER the k loop: allocate result_sbuf=(TM,TN) in nl.sbuf, dtype=lhsT.dtype.
nisa.tensor_copy(dst=result_sbuf,src=acc)
nisa.dma_copy(dst=out[m*TM:(m+1)*TM,n*TN:(n+1)*TN],src=result_sbuf)
Repeat for ALL output tiles, then return out.
Every DMA source/destination must have matching element counts. Buffers remain two-dimensional.
nc_matmul operands must be in SBUF, destination in PSUM; tensor_copy PSUM->SBUF, dma_copy SBUF->HBM.
Do not use framework matmul, dot, einsum, Python @, host transpose, or invented API flags.
Focus on correctness, not level-5/6/7 data-reuse optimization or unmeasured device timing.
"""

def available_names_4(dotted):
    return (f' `{dotted}` does not exist. Do not guess similar names. '
            'Use the tiled nc_matmul / tensor_copy / dma_copy pattern in the API card.')

def real_signature_4(func_name):
    """The actual signature of an NKI function, for when the model invents arguments."""
    import inspect
    for mod_name in ("nki.language", "nki.isa", "nki"):
        try:
            mod = __import__(mod_name, fromlist=["x"])
        except Exception:
            continue
        fn = getattr(mod, func_name, None)
        if fn is None:
            continue
        try:
            return f"{mod_name.split('.')[-1]}.{func_name}{inspect.signature(fn)}"
        except (TypeError, ValueError):
            return f"{mod_name.split('.')[-1]}.{func_name}"
    return ""

def enrich_4(error_text, source='', error=None):
    location = ''
    tb = getattr(error, '__traceback__', None)
    while tb:
        if '_agent_level' in tb.tb_frame.f_code.co_filename:
            lines = source.splitlines()
            line = lines[tb.tb_lineno-1] if tb.tb_lineno <= len(lines) else ''
            location = f' Candidate line {tb.tb_lineno}: {line.strip()[:180]}. '
        tb = tb.tb_next
    prefix = error_text + location
    if 'partition dimension' in error_text and 'exceeds' in error_text:
        return prefix + ' Do not allocate the whole input as an SBUF tile. Use lhs=(128,128), rhs=(128,512), result tile=(128,512). Slice K/M/N with the loop indices before each DMA copy.'
    if 'contraction dimension' in error_text and 'exceeds' in error_text:
        return prefix + ' Split K into chunks of 128. Allocate one float32 PSUM accumulator outside the K loop for each output tile and accumulate all K chunks into it.'
    if 'same number of elements' in error_text:
        return prefix + ' Match each DMA slice to its tile: lhs=(TK,TM), rhs=(TK,TN), output slice=(TM,TN). Do not copy a whole tensor into a fixed tile.'
    if 'must have at least 2 dimensions' in error_text:
        return prefix + ' Use two-dimensional tiles: lhs=(128,128), rhs=(128,512), PSUM/result tile=(128,512).'
    if 'cannot reshape array of size' in error_text:
        return prefix + ' Do not reshape; tile by slicing the original (K,M) and (K,N) tensors using m,n,k loop indices.'
    if "'MemoryRegion' object is not callable" in error_text:
        return prefix + ' Allocate with nl.ndarray(shape,dtype=...,buffer=nl.sbuf or nl.psum); memory regions are not functions.'
    if 'shared_hbm' in error_text and 'must be in' in error_text:
        return prefix + ' nc_matmul writes PSUM; tensor_copy moves PSUM->SBUF; dma_copy stores SBUF into the current HBM output slice after the K loop.'
    if 'must be in' in error_text:
        return prefix + ' nc_matmul dst uses float32 nl.psum; stationary and moving both use nl.sbuf.'
    match = re.search(r"(\w+)\(\) got an unexpected keyword argument '(\w+)'", error_text)
    if match:
        signature = real_signature_4(match.group(1))
        return prefix + f' Remove unsupported `{match.group(2)}=`.' + (f' Installed signature: {signature}.' if signature else '') + ' Use the reference nc_matmul call; lhsT is already laid out correctly.'
    if 'has no attribute' in error_text or 'unsupported operand type' in error_text:
        return prefix + ' Use nisa.nc_matmul repeatedly into one PSUM tile. Do not add NKI tensors with Python += or invented nisa.add.'
    return prefix + ' Check K-chunk accumulation, coverage of every M/N tile, and the final output slice indices.'

def first_prompt_4(level, terse=0):
    if level != 4:
        raise ValueError('This version enables level 4 only.')
    entry = nkibench.LEVELS[4]['entry']
    return (
        f'Write a complete tiled NKI matmul function {entry}(lhsT,rhs), decorated with @nki.jit.\n'
        'Compute lhsT.T @ rhs mathematically using NKI, without modifying inputs. Derive K,M,N from inputs.\n'
        'The full tensors exceed a single tile: use M/N output loops and a K accumulation loop.\n'
        + API_CARD_4 + '\nReturn one complete concise Python code block, no prose.'
    )

def repair_prompt_4(level, source, feedback):
    if level != 4:
        raise ValueError('This version enables level 4 only.')
    if len(source) > 10000:
        return first_prompt_4(4) + '\nRewrite concisely; previous failure:\n' + feedback[:1800]
    return (
        f'Repair tiled NKI matmul `{nkibench.LEVELS[4]["entry"]}`.\n'
        + API_CARD_4 + '\nPrevious candidate:\n```python\n' + source + '\n```\n'
        + 'Checker feedback:\n' + feedback[:1800] + '\n'
        'Fix the reported issue first, allowing related loop/allocation changes. '
        'One PSUM accumulator per output tile, outside the K loop; store after all K chunks. '
        'Return one complete concise Python code block, no prose.'
    )

CODE_BLOCK_4 = re.compile(r"```(?:python)?\s*(.*?)```", re.S)

def extract_code_4(text):
    """Pull out the code, and return NOTHING rather than prose.
    The old fallback returned the whole reply whenever it contained "def ", so a numbered list
    or a sentence reached the compiler and produced "invalid decimal literal on line 2" -- a
    parse error that blamed the model for the extractor's mistake.
    """
    text = text or ""
    blocks = CODE_BLOCK_4.findall(text)
    if blocks:
        return max(blocks, key=len).strip()
    # No fence: start at the first line that can legally begin a module and keep the rest.
    lines = text.splitlines()
    for i, line in enumerate(lines):
        if re.match(r"^\s*(import |from |@nki|def )", line):
            return "\n".join(lines[i:]).strip()
    return ""

def ask_4(a, prompt):
    import httpx
    # enable_thinking=False matters. Qwen3 reasons before answering, and with thinking on it
    # spent the whole budget there: the first cluster run returned "No code came back" at 54.7s
    # over and over, plus truncated fragments (invalid decimal literal, unterminated string).
    # Keep prompt + answer inside the server's context, or the answer is silently cut off and
    # every parse error below is really a budget error. Repair prompts grow with the kernel.
    # Conservative character estimate; still not an exact tokenizer count.
    est_prompt = (len(prompt) + 2) // 3
    remaining = a.context - est_prompt - 256
    if remaining < 256:
        raise SystemExit("Prompt exceeds the safe context budget; shorten the candidate/feedback.")
    budget = min(a.max_tokens, remaining)
    if budget < a.max_tokens:
        print(f"    (prompt is ~{est_prompt} tokens, so the answer budget is capped at {budget} "
              f"to stay inside the {a.context}-token context)")
    body = dict(model=a.model, messages=[{"role": "user", "content": prompt}],
                max_tokens=budget, temperature=0.6, top_p=0.95,
                chat_template_kwargs={"enable_thinking": a.think})
    r = httpx.post(f"{a.base.rstrip('/')}/chat/completions", json=body,
                   timeout=900, verify=False)
    if r.status_code != 200:
        raise SystemExit(f"the endpoint returned HTTP {r.status_code}:\n{r.text[:600]}")
    payload = r.json()
    ch = payload["choices"][0]
    msg = ch.get("message", {})
    reasoning = next((msg[k] for k in REASONING_KEYS_4 if msg.get(k)), "")
    content = msg.get("content") or ""
    finish = ch.get("finish_reason")
    if finish == "length":
        # Do not let a budget problem look like a model failure.
        print(f"    (TRUNCATED: finish_reason=length after {len(content)} chars. The answer was "
              f"cut off, so any parse error below is the budget, not the model. Prompt is "
              f"{len(prompt)} chars; server context is the ceiling.)")
    if not content.strip() and reasoning:
        # The single most common surprise on this endpoint, so name it rather than reporting
        # an empty answer as a model failure.
        print(f"    (empty answer, {len(reasoning)} chars of hidden reasoning, "
              f"finish={ch.get('finish_reason')} — shorten the prompt rather than raising the "
              f"budget)")
    return content

def ask_parallel_4(a, prompt, n):
    import concurrent.futures as cf
    with cf.ThreadPoolExecutor(max_workers=n) as ex:
        return [f.result() for f in [ex.submit(ask_4, a, prompt) for _ in range(n)]]

def offline_answers_4(level, n, rnd):
    """No model. Replays the shipped reference, preceded by a deliberately broken version, so the
    loop and the feedback path can be exercised with no endpoint. Never report a number."""
    ref = open(f"reference_level{level}.py").read()
    if rnd == 0:
        broken = ref.replace("@nki.jit", "", 1)
        return [f"```python\n{broken}\n```"] * n
    return [f"```python\n{ref}\n```"] * n

def solve_4(a, level, log):
    print(f"\n=========== level {level}: {nkibench.LEVELS[level]['op']} ===========")
    terse = a.terse
    prompt = first_prompt_4(level, terse)
    best = (0.0, None, "")
    tried, streak, seen = [], 0, {}
    latest = ("", "")
    for rnd in range(a.rounds):
        t0 = time.perf_counter()
        replies = (offline_answers_4(level, a.samples, rnd) if a.offline
                   else ask_parallel_4(a, prompt, a.samples))
        graded = []
        for reply in replies:
            src = extract_code_4(reply)
            reward, parts, feedback = grade_4(src, level)
            graded.append((reward, src, feedback, parts))
            log.write(json.dumps(dict(level=level, round=rnd, reward=reward, parts=parts,
                                      prompt_chars=len(prompt), reply_chars=len(reply),
                                      code=src, feedback=feedback)) + "\n")
        log.flush()
        graded.sort(key=lambda g: g[0], reverse=True)
        top = graded[0]
        if top[0] > best[0]:
            best = (top[0], top[1], top[2])
        # Repair the LATEST attempt, not the best one. Rebuilding from the best attempt with the
        # best attempt's feedback is a fixed point: once a round scores worse, the prompt stops
        # changing, and a greedy model then returns the same answer forever. Measured: level 2
        # stuck at 0.10 for four rounds while the prompt still carried the 0.50 code.
        if (top[1] or "").strip():
            latest = (top[1], top[2])
        same = top[2] == (tried[-1] if tried else None)
        if same:
            # Collapse. Fifteen identical multi-line blocks is noise, not information.
            print(f"round {rnd}: same failure again ({top[0]:.2f}, best so far {best[0]:.2f})")
        else:
            print(f"round {rnd}: this round {top[0]:.2f}  best so far {best[0]:.2f}  "
                  f"({time.perf_counter() - t0:.1f}s)")
            print(f"  {top[2][:400]}")
        if top[0] >= sum(WEIGHTS_4.values()) - 1e-9:
            print(f"  SOLVED on round {rnd}. {top[2]}")
            print("  ---------------- the kernel ----------------")
            print(textwrap.indent(top[1], "  "))
            print("  -------------------------------------------")
            if not a.offline:
                with open("solution_level4.py", "w") as saved:
                    saved.write(top[1])
                print("  saved successful candidate to solution_level4.py")
            return top[0], rnd + 1
        seen[top[2]] = seen.get(top[2], 0) + 1
        streak = streak + 1 if same else 1
        if seen[top[2]] >= a.give_up_after:
            how = ("the identical failure %d rounds running" % streak if streak >= a.give_up_after
                   else "this failure for the %dth time, alternating with %d other(s)"
                        % (seen[top[2]], len(seen) - 1))
            print(f"  STOPPING this level: {how}. The agent is cycling between a fixed set of "
                  f"mistakes rather than converging, so more rounds will not help. Failures seen:")
            for f, n in sorted(seen.items(), key=lambda kv: -kv[1]):
                print(f"    {n}x  {f[:110]}")
            return best[0], rnd + 1
        tried.append(top[2])
        repeats = streak
        if repeats >= 2 and (best[1] or "").strip():
            # Sampling on this endpoint is greedy, so an unchanged prompt returns an unchanged
            # answer. Measured: the same TypeError 19 rounds running. Changing the prompt is the
            # only thing that can change the answer, so say what has already been tried.
            ledger = "\n".join(f"- {t[:160]}" for t in list(dict.fromkeys(tried))[-2:])
            prompt = (repair_prompt_4(level, latest[0], latest[1])
                      + f"\n\nThese approaches have already failed, so do something different:\n"
                        f"{ledger}")
            print(f"  same failure {repeats}x — adding a ledger of {len(set(tried))} failed "
                  f"attempts to break the repeat")
            continue
        if not (latest[0] or "").strip():
            # Nothing came back to repair. Asking it to "fix" an empty code block produced a
            # 202-character prompt and, under greedy sampling, the identical non-answer six
            # rounds running. Shorten and re-ask instead.
            terse = min(terse + 1, 2)
            prompt = first_prompt_4(level, terse)
            print(f"  no code yet, so re-asking with a shorter prompt (terseness {terse})")
        else:
            prompt = repair_prompt_4(level, latest[0], latest[1])
    print(f"  not solved in {a.rounds} rounds; best reward {best[0]:.2f}")
    return best[0], a.rounds


# Shared command-line interface; each level keeps its own original execution path.
MODEL = MODEL_1
WEIGHTS = WEIGHTS_1
MIN_ANSWER_TOKENS = MIN_ANSWER_TOKENS_1

def first_prompt(level, terse=0):
    return {1:first_prompt_1, 2:first_prompt_2, 3:first_prompt_3, 4:first_prompt_4}[level](level, terse)

def repair_prompt(level, source, feedback):
    return {1:repair_prompt_1, 2:repair_prompt_2, 3:repair_prompt_3, 4:repair_prompt_4}[level](level, source, feedback)

def enrich(error_text, source='', error=None, level=1):
    return {1:enrich_1, 2:enrich_2, 3:enrich_3, 4:enrich_4}[level](error_text, source, error)

def candidate_violations(source, level):
    return {1:pool_api_violations_1, 2:transpose_api_violations_2,
            3:matmul_api_violations_3, 4:matmul_api_violations_4}[level](source)

def check_transpose_exact(got, want, case):
    return check_transpose_exact_2(got, want, case)

def grade(source, level):
    return {1:grade_1, 2:grade_2, 3:grade_3, 4:grade_4}[level](source, level)

def solve(a, level, log):
    return {1:solve_1, 2:solve_2, 3:solve_3, 4:solve_4}[level](a, level, log)

def main():
    ap = argparse.ArgumentParser()
    selection = ap.add_mutually_exclusive_group()
    selection.add_argument("--level", type=int, choices=(1, 2, 3, 4))
    selection.add_argument("--all", action="store_true", help="test levels 1-4 in order")
    ap.add_argument("--rounds", type=int, default=4)
    ap.add_argument("--samples", type=int, default=2)
    ap.add_argument("--max-tokens", type=int, default=3500)
    ap.add_argument("--model", default=MODEL)
    ap.add_argument("--base", default=os.environ.get("KERNEL_AGENT_BASE_URL")
                    or os.environ.get("GPTOSS_BASE_URL"))
    ap.add_argument("--path", default="", help="path to append, e.g. /agg/v1 for gpt-oss")
    ap.add_argument("--repeat", type=int, default=1,
                    help="run the whole thing N times and report a solve RATE. One run is not a "
                         "result: measured, the same config scored 1.00, 1.00 and 0.50 on level 2 "
                         "across three runs with no code change.")
    ap.add_argument("--log", default="attempts_four_backups.jsonl")
    ap.add_argument("--give-up-after", type=int, default=4,
                    help="stop a level after this many identical failures in a row. Measured: 15 "
                         "was pure waste, because the prompt had stopped changing.")
    ap.add_argument("--terse", type=int, default=0, choices=(0, 1, 2),
                    help="starting prompt length. Measured on gpt-oss-20b: 0 produced 13,245 "
                         "chars of hidden reasoning and no answer, while 1 answered with code. "
                         "Qwen3-8B is fine at 0.")
    ap.add_argument("--context", type=int, default=8192,
                    help="the server's max-model-len; prompt + answer must fit inside it")
    ap.add_argument("--think", action="store_true",
                    help="let the model reason first; costs budget, and it ran out")
    ap.add_argument("--offline", action="store_true")
    a = ap.parse_args()
    if not a.offline:
        # Validate before the first request. An empty or scheme-less value produces a hostname
        # starting with "." and 30 lines of httpx/idna traceback that say nothing about the cause.
        raw = (a.base or "").strip()
        if not raw:
            sys.exit("KERNEL_AGENT_BASE_URL is empty or unset. Point it at a model:\n"
                     "  export KERNEL_AGENT_BASE_URL=http://localhost:8000/v1\n"
                     "  export KERNEL_AGENT_MODEL=Qwen/Qwen3-8B\n"
                     "That is the server ./serve.sh started. The seat pods set these for you; if they are "
                     "missing, you are not in a seat pod. Or pass --offline to run with no model.\n"
                     "(Separately: the shared gpt-oss endpoint is reached by setting "
                     "GPTOSS_BASE_URL and passing --path /agg/v1 -- not needed for the local run.)")
        from urllib.parse import urlparse
        u = urlparse(raw)
        if u.scheme not in ("http", "https") or not u.netloc:
            sys.exit(f"base URL {raw!r} is not usable. It needs a scheme and a host, e.g. "
                     f"http://qwen3-8b:8000/v1.")
        a.base = raw.rstrip("/") + a.path
        print(f"endpoint {a.base}  model {a.model}")
    else:
        print("*** OFFLINE: replaying the reference kernel. Numbers are meaningless. ***")
    levels = [1, 2, 3, 4] if a.all else [a.level or 1]
    full = sum(WEIGHTS.values())
    history = {lv: [] for lv in levels}

    with open(a.log, "a") as log:
        for rep in range(a.repeat):
            a.run_index = rep + 1
            if a.repeat > 1:
                print(f"\n################ run {rep + 1} of {a.repeat} ################")
            results = []
            for level in levels:
                results.append((level,) + solve(a, level, log))
                history[level].append(results[-1][1])
            print("\n=========== summary ===========")
            for level, reward, rounds in results:
                print(f"  level {level}  reward {reward:.2f} after {rounds} round(s)"
                      + ("  SOLVED" if reward >= full - 1e-9 else ""))
            print(f"  solved {sum(1 for _, r, _ in results if r >= full - 1e-9)}/{len(results)}")
    if a.repeat > 1:
        # The number that actually means something. A solve rate over N runs survives the variance
        # that makes any single run uninterpretable.
        print(f"\n=========== over {a.repeat} runs ===========")
        for lv in levels:
            got = history[lv]
            solves = sum(1 for r in got if r >= full - 1e-9)
            print(f"  level {lv}: solved {solves}/{len(got)}  "
                  f"best {max(got):.2f}  worst {min(got):.2f}  "
                  f"mean {sum(got) / len(got):.2f}  all={[round(r, 2) for r in got]}")
        print("\n  Report the rate, not your best run. A level that solves 1 in 3 times is not solved.")
    print(f"\nattempts logged to {a.log}")


if __name__ == "__main__":
    main()
