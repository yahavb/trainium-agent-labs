# Token instrumentation

These are estimates, not tokenizer counts. `attempts.jsonl` stores `prompt_chars` and `reply_chars`. The endpoint did not return a usage object, and `run.log` has no truncation or budget warning. Estimated tokens = characters / 4. That is the same estimate `agent.py` uses when it caps `max_tokens` against the 8192 context.

Window: the last 200 records of `attempts.jsonl`, which are this run (5 runs × 10 rounds × 4 samples). The first record's feedback contains the level-1 recipe ("Throw away the per-window"), so the window is not an earlier experiment. All four samples in a round share one prompt.

## Where a prompt's characters were counted

- **Docs.** Round 0 is the whole first prompt: the operation, the NumPy reference, the hardware limits, and `API_CARD` (1,581 characters, about 395 tokens). There is no previous kernel and no checker text. On a repair round, docs is whatever is left after the previous kernel and the checker text are subtracted: the short wrapper plus the one change instruction.
- **Error.** The checker feedback carried into the next prompt.
- **Code.** The previous kernel carried into the next prompt.

`docs + error + code` equals `prompt_chars` on every repair round in this window. Nothing was left over and nothing went negative.

## Totals, 200 calls

| | Characters | Estimated tokens | Share of input |
|---|---:|---:|---:|
| Input, all of it | 536,220 | 134,055 | 100% |
| Docs | 233,760 | 58,440 | 43.6% |
| Error | 166,088 | 41,522 | 31.0% |
| Code | 136,372 | 34,093 | 25.4% |
| Output (replies) | 239,193 | 59,798 | not input |

Mean input is about 670 tokens per call. The largest prompt is run 4, level 4, round 1: 4,311 characters, about 1,078 tokens. That is the round whose feedback was the long numerical mismatch. The smallest is a level-1 repair, 1,517 characters, about 379 tokens. No call came near 8192.

Round 0 is 80 of the 200 calls (4 levels × 5 runs × 4 samples) and is 100% docs: 198,880 characters, about 49,720 tokens. The 120 repair calls are where the budget actually moves:

| Repair calls only (120) | Estimated tokens | Share of those prompts |
|---|---:|---:|
| Docs (wrapper + the one change) | 8,720 | 10.3% |
| Error (checker feedback) | 41,522 | 49.2% |
| Code (previous kernel) | 34,093 | 40.4% |

## Input per round

Round 0 is identical on all five runs. Repair sizes move a little with the kernel the model wrote; the table gives the range.

| Level | Round | Calls | Prompt chars | Est. input tokens | Docs | Error | Code |
|---|---|---:|---:|---:|---:|---:|---:|
| 1 | 0 | 20 | 2,323 | 581 | 581 | 0 | 0 |
| 1 | 1 | 20 | 2,861 | 715 | 70 | 423 | 222 |
| 1 | 2 | 20 | 1,517–1,553 | 379–388 | 51 | 69 | 260–269 |
| 2 | 0 | 20 | 2,673 | 668 | 668 | 0 | 0 |
| 2 | 1 | 20 | 2,898–3,073 | 725–768 | 84 | 454 | 187–231 |
| 3 | 0 | 20 | 2,477 | 619 | 619 | 0 | 0 |
| 3 | 1 | 20 | 3,275–3,284 | 819–821 | 92 | 497–499 | 228–232 |
| 4 | 0 | 20 | 2,471 | 618 | 618 | 0 | 0 |
| 4 | 1 | 20 | 3,685–4,311 | 921–1,078 | 90 | 547–596 | 284–392 |
| 4 | 2 | 20 | 2,431–2,457 | 608–614 | 49 | 76 | 483–489 |

Round 0 spends the input on the spec. From round 1 on, about half of each prompt is the checker report and about 40% is the kernel being repaired. The API card is not sent again.
