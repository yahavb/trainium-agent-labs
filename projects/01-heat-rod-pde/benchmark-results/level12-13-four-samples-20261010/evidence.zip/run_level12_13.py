"""Two real-Qwen cases, latest E Agent, four samples per round."""
import datetime as dt
import importlib.util
import json
import os
from pathlib import Path
import shutil
import signal
import subprocess
import sys
import time

ROOT=Path('/tmp/heatrod-level12-13-four-samples-20261010')
PRIOR=Path('/tmp/heatrod-quick-20261010-api-aligned/resilience/projects/01-heat-rod-pde')
COMMIT='cd16f7b57a878661bb371f4c1ef09bd6864ff356'


def main():
    source=ROOT/'source'
    source.mkdir()
    for path in PRIOR.glob('*.py'): shutil.copy2(path,source/path.name)
    sys.path.insert(0,str(source))
    spec=importlib.util.spec_from_file_location('harness',source/'algorithm_benchmark.py')
    harness=importlib.util.module_from_spec(spec)
    spec.loader.exec_module(harness)
    base=os.environ.get('HEATROD_BASE_URL','http://localhost:8000/v1')
    model='Qwen/Qwen3-8B'
    doc=dict(status='running',commit=COMMIT,started_utc=dt.datetime.now(dt.timezone.utc).isoformat(),
             settings=dict(model=model,cases=[[1,2,0],[1,3,0]],samples=4,rounds=3,workers=2,
                           max_tokens=512,tool_steps=1,outer_deadline=180,internal_deadline=177,
                           features='cache,final,feedback,adaptive',seed=0,repeat=1,
                           grading_policy='original_checker',additional_validation_status='not_run'),
             environment=harness.environment(),health=harness.health(base,model),results=[])
    def save(): harness.write_json(ROOT/'comparison.json',doc)
    save()
    if not doc['health']['available']:
        doc['status']='stopped_service_unavailable'; save(); return
    for sub in (2,3):
        folder=ROOT/f'level1.{sub}-seed0'; folder.mkdir()
        command=[sys.executable,'-u',str(source/'algorithm_benchmark.py'),'--worker','E',
                 '--case-dir',str(folder),'--level','1','--sub',str(sub),'--seed','0',
                 '--samples','4','--rounds','3','--workers','2','--max-tokens','512',
                 '--tool-steps','1','--deadline','180','--base',base,'--model',model,
                 '--combined-features','cache,final,feedback,adaptive']
        harness.write_json(folder/'invocation.json',dict(command=command,commit=COMMIT))
        print('START',sub,flush=True); start=time.perf_counter(); outer='unsolved'
        with (folder/'console.log').open('w') as stream:
            proc=subprocess.Popen(command,cwd=source,stdout=stream,stderr=subprocess.STDOUT,
                                  start_new_session=True,env=dict(os.environ,HEATROD_SOURCE_COMMIT=COMMIT))
            try:
                code=proc.wait(timeout=180)
                if code: outer='worker_error'
            except subprocess.TimeoutExpired:
                outer='budget_timeout'; os.killpg(proc.pid,signal.SIGKILL); proc.wait(); code=proc.returncode
        result=harness.summarize_case(folder,(1,sub,0),'E',outer)
        rows=[row for path in folder.glob('**/attempts.jsonl') for row in harness.read_jsonl(path)]
        result.update(level=1,sub=sub,seed=0,seconds=time.perf_counter()-start,exit_code=code,
                      case_path=folder.name,outer_status=outer,
                      sample_scores=[dict(round=row.get('round'),sample=row.get('sample'),
                                          reward=(row.get('grade') or {}).get('reward'),error=row.get('error')) for row in rows])
        doc['results'].append(result); save()
        print('DONE',sub,result['status'],result['reward'],round(result['seconds'],1),flush=True)
        if outer=='worker_error' or result['status']=='infrastructure_error' or result['http_error_statuses']:
            doc['status']='stopped_service_or_worker_error'; save(); return
    doc.update(status='complete',finished_utc=dt.datetime.now(dt.timezone.utc).isoformat()); save()
    print('COMPLETE',flush=True)


if __name__=='__main__':
    if '--launch' in sys.argv:
        ROOT.mkdir(exist_ok=False)
        with (ROOT/'suite-console.log').open('w') as stream:
            proc=subprocess.Popen([sys.executable,'-u',str(Path(__file__).resolve())],
                                  stdout=stream,stderr=subprocess.STDOUT,start_new_session=True)
        print(json.dumps(dict(pid=proc.pid,root=str(ROOT))))
    else: main()
