"""Exactly two fixed PDE cases, one run per case per branch, real Qwen only."""
import datetime as dt
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import shutil
import signal
import subprocess
import sys
import tarfile
import time

ROOT = Path('/tmp/heatrod-quick-20261010-api-aligned')
COMMITS = {'master': 'b94759c18e91139a128ed260b6a7dd18ba59148d',
           'resilience': 'a4b58a5b0ec6f4cc96ab7d9517cb35c00b0cbb68'}
FEATURES = 'cache,final,feedback,adaptive'


def save(document):
    target = ROOT/'comparison.json'
    temporary = target.with_suffix('.tmp')
    temporary.write_text(json.dumps(document, indent=2, allow_nan=False))
    temporary.replace(target)


def run():
    sources = {}
    for branch in COMMITS:
        destination = ROOT/branch
        destination.mkdir(exist_ok=False)
        with tarfile.open(ROOT/(branch+'.tar')) as archive:
            for member in archive.getmembers():
                path = (destination/member.name).resolve()
                if destination.resolve() not in path.parents or not (member.isfile() or member.isdir()):
                    raise ValueError('Unsupported archive member')
            archive.extractall(destination)
        sources[branch] = destination/'projects/01-heat-rod-pde'
    harness = sources['resilience']/'algorithm_benchmark.py'
    shutil.copy2(harness, sources['master']/harness.name)
    sys.path.insert(0, str(sources['resilience']))
    spec = importlib.util.spec_from_file_location('quick_harness', harness)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    base = os.environ.get('HEATROD_BASE_URL', 'http://localhost:8000/v1')
    model = 'Qwen/Qwen3-8B'
    plan = [('master', 'previous', 0, 1, 0), ('resilience', 'E', 0, 1, 0),
            ('resilience', 'E', 1, 1, 0), ('master', 'previous', 1, 1, 0)]
    document = dict(status='running', commits=COMMITS,
                    started_utc=dt.datetime.now(dt.timezone.utc).isoformat(),
                    settings=dict(model=model, cases=[[0,1,0],[1,1,0]], repeat=1,
                                  samples=2, rounds=3, max_tokens=512, tool_steps=1,
                                  workers=2, outer_deadline=180, algorithm_deadline=177,
                                  transport_retries=0, temperature=.6, top_p=.95,
                                  thinking=False, features=FEATURES,
                                  grading_policy='original_checker', additional_validation='not_run',
                                  model_random_seed_sent=False, order=plan),
                    environment=module.environment(), health=module.health(base,model), results=[])
    document['source_sha256'] = {branch: {path.name: hashlib.sha256(path.read_bytes()).hexdigest()
                                       for path in sources[branch].glob('*.py')} for branch in COMMITS}
    document['shared_core_identical'] = {name: (sources['master']/name).read_bytes()==(sources['resilience']/name).read_bytes()
                                        for name in ('agent.py','improved_agent.py','pdecheck.py','checker_runtime.py','tool_calc.py','level0_heatrod.py','level1_heatrod.py')}
    save(document)
    if not document['health']['available']:
        document['status']='stopped_service_unavailable'
        save(document)
        return
    for branch, variant, level, sub, seed in plan:
        folder=ROOT/f'{branch}-level{level}.{sub}-seed{seed}'
        folder.mkdir()
        command=[sys.executable,'-u',str(sources[branch]/'algorithm_benchmark.py'),
                 '--worker',variant,'--case-dir',str(folder),'--level',str(level),
                 '--sub',str(sub),'--seed',str(seed),'--samples','2','--rounds','3',
                 '--max-tokens','512','--tool-steps','1','--workers','2','--deadline','180',
                 '--model',model,'--base',base,'--combined-features',FEATURES]
        (folder/'invocation.json').write_text(json.dumps(dict(command=command,cwd=str(sources[branch]),commit=COMMITS[branch]),indent=2))
        print('START',branch,level,flush=True)
        start=time.perf_counter()
        status='unsolved'
        with (folder/'console.log').open('w') as stream:
            process=subprocess.Popen(command,cwd=sources[branch],stdout=stream,stderr=subprocess.STDOUT,
                                     start_new_session=True,env=dict(os.environ,HEATROD_SOURCE_COMMIT=COMMITS[branch]))
            try:
                code=process.wait(timeout=180)
                if code: status='worker_error'
            except subprocess.TimeoutExpired:
                status='budget_timeout'
                os.killpg(process.pid,signal.SIGKILL)
                process.wait()
                code=process.returncode
        elapsed=time.perf_counter()-start
        result=module.summarize_case(folder,(level,sub,seed),variant,status)
        result.update(branch=branch,level=level,sub=sub,seed=seed,seconds=elapsed,exit_code=code,
                      outer_status=status,case_path=folder.name,commit=COMMITS[branch])
        document['results'].append(result)
        print('DONE',branch,level,result['status'],result['reward'],round(elapsed,1),flush=True)
        if status=='worker_error' or result['status']=='infrastructure_error' or result.get('http_error_statuses'):
            document['status']='stopped_service_or_worker_error'
            save(document)
            return
        save(document)
    document.update(status='complete',finished_utc=dt.datetime.now(dt.timezone.utc).isoformat())
    save(document)
    print('COMPLETE',flush=True)


if __name__=='__main__':
    if '--launch' in sys.argv:
        with (ROOT/'suite-console.log').open('w') as output:
            process=subprocess.Popen([sys.executable,'-u',str(Path(__file__).resolve())],
                                     stdout=output,stderr=subprocess.STDOUT,start_new_session=True)
        print(json.dumps(dict(pid=process.pid,root=str(ROOT))))
    else:
        run()
